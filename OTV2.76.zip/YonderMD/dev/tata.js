const fsEnv = require('fs')
const pathEnv = require('path')
try { const envFile = pathEnv.join(__dirname, '..', '.env'); if (fsEnv.existsSync(envFile)) { for (const line of fsEnv.readFileSync(envFile,'utf8').split(/\r?\n/)) { const m=line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/i); if (m && !process.env[m[1]]) process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,'') } } } catch {}
const { spawn } = require('child_process')

let bot
let stopping = false

function startBot() {
    bot = spawn('node', ['./dev/index.js'], { stdio: 'inherit' })

    bot.on('exit', (code, signal) => {
        if (stopping || signal || code === 0) return
        setTimeout(startBot, 1500)
    })
}

function stop(signal) {
    stopping = true
    bot?.kill(signal)
}

process.once('SIGINT', () => stop('SIGINT'))
process.once('SIGTERM', () => stop('SIGTERM'))

startBot()
