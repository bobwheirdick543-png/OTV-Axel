module.exports = {
  "antiOnce": false,
  "antiOnce2": true,
  "totallog": true,
  "grplog": false,
  "rootColor": "\u001b[32m",
  "shapeColor": "\u001b[32m",
  "logColor": "\u001b[32m",
  "hideNumber": false,
  "ownerNumber": "2349033047066",
  "version": "V2.2.0",
  "defaultPrefix": ".",
  "root": "===> "
};