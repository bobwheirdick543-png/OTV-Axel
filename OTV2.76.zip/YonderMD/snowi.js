const DEFAULT_DELAY = 1000
const country = 'de-DE'

const {
    generateWAMessageFromContent,
    getAggregateVotesInPollMessage,
    downloadContentFromMessage,
    encodeSignedDeviceIdentity,
    makeCacheableSignalKeyStore,
    prepareWAMessageMedia,
    downloadMediaMessage,
    useMultiFileAuthState,
    generateMessageIDV2,
    makeInMemoryStore,
    generateWAMessage,
    generateMessageID,
    encodeWAMessage,
    PHONENUMBER_MCC,
    DisconnectReason,
    getBusinessProfile,
    getContentType,
    makeWASocket,
    msgRetryCounterCache,
    areJidsSameUser,
    decryptPollVote,
    hmacSign,
    aesEncryptGCM,
    relayMessage,
    jidDecode,
    jidEncode,
    authState,
    Browsers,
    crypto_1,
    Utils_1,
    WABinary_1,
    WAProto_1,
    fetchLatestversion,
    WAProto,
    getDevice,
    proto,
} = require('@vansnowi/baileys')

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const moment = require('moment-timezone')
const pino = require('pino')
const logger = pino({ level: 'debug' })
const crypto = require('crypto')
const path = require('path')
const os = require('os')
const { spawn } = require('child_process')
let FFMPEG_PATH = process.env.FFMPEG_PATH || 'ffmpeg'
try { FFMPEG_PATH = process.env.FFMPEG_PATH || require('@ffmpeg-installer/ffmpeg').path || 'ffmpeg' } catch {}
const { log } = require('./dev/consts.js')
const { get: giftedGet } = require('./lib/gifted')
const { toBuffer: mediaToBuffer } = require('./lib/media')
const { registry: gameRegistry } = require('./lib/game-engine')
const { dispatch: dispatchBattleversia } = require('./lib/battleversia')
const { syncFile: syncPersistentFile } = require('./lib/supabase-persistence')

const DATA_DIR = path.join(__dirname, 'dev', 'data')
const ASSET_DIR = path.join(__dirname, 'dev', 'assets')
const DATA_FILE = path.join(DATA_DIR, 'bot-data.json')
const MENU_STATE_FILE = path.join(DATA_DIR, 'menu-state.json')
const PLUGIN_DIR = path.join(DATA_DIR, 'plugins')
const MENU_IMAGES = [
    path.join(ASSET_DIR, 'menu-1.jpg'),
    path.join(ASSET_DIR, 'menu-2.jpg'),
    path.join(ASSET_DIR, 'menu-3.jpg'),
]
const BOT_NAME = 'Yonder MD'
const DEVELOPER = 'The Beyonder'
const DEFAULT_PREFIX = '.'
const START_TIME = Date.now()
const CREATOR_NUMBER = '2349033047066'
const BOT_VERSION = 'V2.2.0'
const PUBLIC_COMMANDS = new Set(['menu','help','ping','play','playdoc','sticker','take','uptime','tagall','hidetag','wcg','join','battleversia','bv','gift','bvgift','oncv','aonc','test','stats','wcgstats','leaderboard','wcgleaderboard','achievements','badges','bmenu','bcmenu','bvname','bal','bvrank','vb','bvh','bvm','bvmarket','bvprofile','bv','bvstats','permissions','admin','sudo','bvseason','gs','pass','p','gsc','bvt','bvtcreate','claim','bvsetsudo','bvdelsudo','bvsudolist','bvaddchar','bc','adp','h'])
const spamCache = new Map()
const reactionCache = new Map()
const loadedPlugins = new Map()

for (const dir of [DATA_DIR, ASSET_DIR, PLUGIN_DIR]) fs.mkdirSync(dir, { recursive: true })

function readJson(file, fallback) {
    try {
        if (!fs.existsSync(file)) return fallback
        return JSON.parse(fs.readFileSync(file, 'utf8'))
    } catch {
        return fallback
    }
}

function writeJson(file, value) {
    fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8')
    if (path.resolve(file) === path.resolve(DATA_FILE)) syncPersistentFile(file).catch(() => {})
}

async function safeReact(snowi, chatId, messageKey, emoji = '✅') {
    const id = String(messageKey?.id || '')
    if (!id || !chatId) return false
    const cacheKey = `${chatId}:${id}:${emoji}`
    const now = Date.now()
    const seenAt = reactionCache.get(cacheKey)
    if (seenAt && now - seenAt < 30000) return false
    reactionCache.set(cacheKey, now)
    if (reactionCache.size > 2000) {
        for (const [k, t] of reactionCache) if (now - t > 60000) reactionCache.delete(k)
    }
    try {
        await snowi.sendMessage(chatId, { react: { text: emoji, key: messageKey } })
        return true
    } catch { return false }
}

let db = readJson(DATA_FILE, { groups: {}, sudo: [], admins: [], system: {} })
if (!db || typeof db !== 'object') db = { groups: {}, sudo: [], admins: [], system: {} }
if (!db.groups || typeof db.groups !== 'object') db.groups = {}
if (!Array.isArray(db.sudo)) db.sudo = []
if (!Array.isArray(db.admins)) db.admins = []
if (!db.system || typeof db.system !== 'object') db.system = {}
if (typeof db.system.prefix !== 'string' || !db.system.prefix) db.system.prefix = DEFAULT_PREFIX
if (typeof db.system.mode !== 'string' || !['public','private'].includes(db.system.mode)) db.system.mode = 'public'
if (typeof db.system.shutdown !== 'boolean') db.system.shutdown = false
if (typeof db.system.commandCount !== 'number') db.system.commandCount = 0
if (!Number.isFinite(Number(db.system.wcgBotDelay)) || Number(db.system.wcgBotDelay) < 1 || Number(db.system.wcgBotDelay) > 50) db.system.wcgBotDelay = 7
if (!db.system.wcgStats || typeof db.system.wcgStats !== 'object') db.system.wcgStats = {}
if (!db.system.wcgCategories || typeof db.system.wcgCategories !== 'object') db.system.wcgCategories = {}
if (!db.system.wcgMode || typeof db.system.wcgMode !== 'object') db.system.wcgMode = {}
writeJson(DATA_FILE, db)

function getPrefix() { return String(db.system.prefix || DEFAULT_PREFIX) }
function displayNameForParticipant(participant, fallback = '') {
    return String(participant?.notify || participant?.name || participant?.verifiedName || fallback || '').replace(/\n/g, ' ').trim()
}
function escapeRegExp(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') }
function parsePrefixSetting(raw) {
    const match = String(raw || '').match(/^\s*prefix\s*=\s*([\s\S]+?)\s*$/i)
    return match ? match[1] : ''
}
function liveCommandUsage(name, extra = '') { return `${getPrefix()}${name}${extra}` }

function getGroupSettings(jid) {
    if (!db.groups[jid]) {
        db.groups[jid] = {
            antibadword: false,
            badwords: [],
            antilink: false,
            antispam: false,
            antitag: false,
            mute: false,
            warnings: {},
            welcome: { enabled: false, text: 'Welcome @user to *{group}* 👋' },
            goodbye: { enabled: false, text: 'Goodbye @user 👋' },
            wcg: { difficulty: 'hard', time: 25, botDelay: 7, mode: 'classic', category: 'general', strict: false, games: true, invalidWarning: true },
        }
        writeJson(DATA_FILE, db)
    }
    const g = db.groups[jid]
    g.badwords = Array.isArray(g.badwords) ? g.badwords : []
    g.warnings = g.warnings && typeof g.warnings === 'object' ? g.warnings : {}
    g.welcome = g.welcome && typeof g.welcome === 'object' ? g.welcome : { enabled: false, text: 'Welcome @user to *{group}* 👋' }
    g.goodbye = g.goodbye && typeof g.goodbye === 'object' ? g.goodbye : { enabled: false, text: 'Goodbye @user 👋' }
    g.wcg = g.wcg && typeof g.wcg === 'object' ? g.wcg : { difficulty: 'hard', time: 25, botDelay: 7, mode: 'classic', category: 'general', strict: false, games: true, invalidWarning: true }
    g.wcg.difficulty = ['easy','hard'].includes(String(g.wcg.difficulty).toLowerCase()) ? String(g.wcg.difficulty).toLowerCase() : 'hard'
    g.wcg.time = WCG_ALLOWED_TIMES?.has(Number(g.wcg.time)) ? Number(g.wcg.time) : 25
    g.wcg.botDelay = Math.min(19, Math.max(1, Number(g.wcg.botDelay) || 7))
    g.wcg.mode = String(g.wcg.mode || 'classic').toLowerCase()
    g.wcg.category = String(g.wcg.category || 'general').toLowerCase()
    g.wcg.strict = !!g.wcg.strict
    g.wcg.games = g.wcg.games !== false
    g.wcg.invalidWarning = g.wcg.invalidWarning !== false
    return g
}

function normalizeJid(jid, snowi) {
    if (!jid) return ''
    try { return snowi.decodeJid(jid) || jid } catch { return jid }
}

function numberOf(jid) {
    return String(jid || '').split('@')[0].split(':')[0]
}

function configuredOwners() {
    // Owner identity is intentionally locked to the creator number.
    // Environment/settings aliases must not create additional owners.
    return [CREATOR_NUMBER]
}

function isOwner(sender, snowi, isBot, ...aliases) {
    if (isBot) return true
    const owners = configuredOwners()
    const allCandidates = [sender, ...aliases].filter(Boolean)
    for (const candidate of allCandidates) {
        const variants = [numberOf(candidate)]
        try { variants.push(numberOf(normalizeJid(candidate, snowi))) } catch {}
        if (variants.some(n => owners.includes(n))) return true
    }
    return false
}

function isAdmin(sender, snowi) {
    const target = normalizeJid(sender, snowi)
    return !!target && db.admins.some(j => {
        try { return areJidsSameUser(normalizeJid(j, snowi), target) } catch { return numberOf(j) === numberOf(target) }
    })
}

function parseToggle(value, current) {
    const v = String(value || '').toLowerCase()
    if (['on', 'enable', 'enabled', 'yes', 'true', '1'].includes(v)) return true
    if (['off', 'disable', 'disabled', 'no', 'false', '0'].includes(v)) return false
    return !current
}

function formatUptime(ms) {
    const s = Math.floor(ms / 1000)
    const d = Math.floor(s / 86400)
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    const sec = s % 60
    return `${String(h).padStart(2,'0')}h ${String(m).padStart(2,'0')}m ${String(sec).padStart(2,'0')}s`
}

function getMentioned(info, x) {
    const candidates = [
        x?.msg?.contextInfo,
        info?.message?.extendedTextMessage?.contextInfo,
        info?.message?.imageMessage?.contextInfo,
        info?.message?.videoMessage?.contextInfo,
    ]
    for (const ctx of candidates) {
        if (Array.isArray(ctx?.mentionedJid)) return ctx.mentionedJid.filter(Boolean)
    }
    return []
}

function getMessageContext(info) {
    return info?.message?.extendedTextMessage?.contextInfo
        || info?.message?.imageMessage?.contextInfo
        || info?.message?.videoMessage?.contextInfo
        || info?.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo
        || {}
}

function getQuotedMessage(info) {
    const ctx = getMessageContext(info)
    let quoted = ctx?.quotedMessage
    if (quoted?.ephemeralMessage?.message) quoted = quoted.ephemeralMessage.message
    if (quoted?.viewOnceMessage?.message) quoted = quoted.viewOnceMessage.message
    return quoted || null
}

function getQuotedParticipant(info, snowi) {
    const participant = getMessageContext(info)?.participant
    return participant ? normalizeJid(participant, snowi) : ''
}

function messageFromQuoted(quoted) {
    if (!quoted) return null
    const type = Object.keys(quoted).find(k => /Message$/.test(k) && !['messageContextInfo'].includes(k)) || Object.keys(quoted)[0]
    if (!type) return null
    return { mtype: type, msg: quoted[type], message: quoted }
}

async function downloadBuffer(snowi, msgObj) {
    return snowi.downloadMediaMessage(msgObj)
}

function runCommand(command, args, options = {}) {
    return new Promise((resolve, reject) => {
        const child = spawn(command, args, { stdio: ['ignore', 'ignore', 'pipe'] })
        let stderr = ''
        child.stderr.on('data', d => { stderr += d.toString() })
        child.on('error', reject)
        child.on('close', code => code === 0 ? resolve() : reject(new Error(stderr || `${command} exited with ${code}`)))
        if (options.timeout) {
            const timer = setTimeout(() => child.kill('SIGKILL'), options.timeout)
            child.on('close', () => clearTimeout(timer))
        }
    })
}

async function addStickerExif(webpBuffer, packname = BOT_NAME, author = DEVELOPER) {
    const WebP = require('node-webpmux')
    const img = new WebP.Image()
    await img.load(webpBuffer)
    const json = {
        'sticker-pack-id': crypto.randomBytes(16).toString('hex'),
        'sticker-pack-name': String(packname || BOT_NAME).slice(0, 120),
        'sticker-pack-publisher': String(author || DEVELOPER).slice(0, 120),
        emojis: ['⚡'],
    }
    const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8')
    const exif = Buffer.concat([
        Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]),
        jsonBuffer,
    ])
    exif.writeUIntLE(jsonBuffer.length, 14, 4)
    img.exif = exif
    return img.save(null)
}

async function makeSticker(buffer, kind = 'image') {
    const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'yonder-sticker-'))
    const input = path.join(temp, kind === 'video' ? 'input.mp4' : 'input.jpg')
    const output = path.join(temp, 'sticker.webp')
    fs.writeFileSync(input, buffer)
    try {
        if (kind === 'video') {
            await runCommand(FFMPEG_PATH, ['-y', '-i', input, '-t', '6', '-vf', 'fps=15,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:-1:-1:color=black@0.0', '-c:v', 'libwebp', '-lossless', '0', '-q:v', '70', '-loop', '0', '-an', output], { timeout: 30000 })
        } else {
            await runCommand(FFMPEG_PATH, ['-y', '-i', input, '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:-1:-1:color=black@0.0', '-c:v', 'libwebp', '-lossless', '0', '-q:v', '70', output], { timeout: 20000 })
        }
        return fs.readFileSync(output)
    } finally {
        fs.rmSync(temp, { recursive: true, force: true })
    }
}

function shuffled(arr) {
    const a = [...arr]
    for (let i = a.length - 1; i > 0; i--) {
        const j = crypto.randomInt(i + 1)
        ;[a[i], a[j]] = [a[j], a[i]]
    }
    return a
}

function nextMenuImage() {
    let state = readJson(MENU_STATE_FILE, { queue: [], last: null })
    if (!Array.isArray(state.queue)) state.queue = []
    if (!state.queue.length) {
        const available = MENU_IMAGES.filter(Boolean)
        let queue = shuffled(available)
        if (queue.length > 1 && state.last && queue[0] === state.last) {
            const swap = queue.findIndex(v => v !== state.last)
            if (swap > 0) [queue[0], queue[swap]] = [queue[swap], queue[0]]
        }
        state.queue = queue
    }
    const image = state.queue.shift()
    state.last = image
    writeJson(MENU_STATE_FILE, state)
    return image
}

function menuText(userDisplayName = 'Unknown', includeAdmin = false) {
    const p = getPrefix()
    const mode = db.system.mode === 'private' ? 'Private' : 'Public'
    const uptime = formatUptime(Date.now() - START_TIME)
    const commandCount = db.system.commandCount || 0
    const admin = includeAdmin ? `
┌〔 *ADMIN* 〕
│ 𒆜 ${p}setsudo ⟡ ${p}delsudo
│ 𒆜 ${p}sudolist ⟡ ${p}plugin
│ 𒆜 ${p}public ⟡ ${p}private
│ 𒆜 ${p}start ⟡ ${p}shutdown
│ 𒆜 ${p}restart
│ 𒆜 ${p}set prefix = <design>
│ 𒆜 ${p}set time = <seconds> [easy|hard]` : ''
    return `𒆜*Yonder MD*
> *Go Beyond the Ordinary, Plus Ultra.*
*SYSTEM INFO*
𒆜 Owner ⫸ 𝑻𝒉𝒆 𝑩𝒆𝒚𝒐𝒏𝒅𝒆𝒓
𒆜 Prefix ⫸ ${p}
𒆜 User ⫸ ${userDisplayName || 'Unknown'}
𒆜 Version ⫸ ${BOT_VERSION}
𒆜 Uptime ⫸ ${uptime}
𒆜 Mode ⫸ ${mode}
𒆜 Commands ⫸ ${commandCount}
𒆜 Status ⫸ Online ⚡
┌〔 *COMMAND CORE* 〕
│ 𒆜 ${p}menu ⟡ ${p}help
│ 𒆜 ${p}ping ⟡ ${p}uptime
│ 𒆜 ${p}play ⟡ ${p}sticker
│ 𒆜 ${p}take ⟡ ${p}oncv
┌〔 *GROUP* 〕
│ 𒆜 ${p}tagall ⟡ ${p}hidetag
│ 𒆜 ${p}kick ⟡ ${p}add
│ 𒆜 ${p}promote ⟡ ${p}demote
│ 𒆜 ${p}mute ⟡ ${p}unmute
│ 𒆜 ${p}antilink ⟡ ${p}antigm
│ 𒆜 ${p}welcome ⟡ ${p}goodbye
┌〔 *PLAYGROUND* 〕
│ 𒆜 ${p}bmenu ⟡ ${p}bv
│ 𒆜 ${p}WCG
${admin}
┌〔 *SYSTEM* 〕
│ 𒆜 ${p}info ⟡ ${p}me
│ 𒆜 ${p}from`;
}

function helpText(includeAdmin = false) {
    const p = getPrefix()
    const sections = [
        ['COMMAND CORE', [
            [`${p}menu`, 'Open the main Yonder MD menu'],
            [`${p}help`, 'Show this complete command guide'],
            [`${p}ping`, 'Check bot response speed'],
            [`${p}uptime`, 'Show current bot uptime'],
            [`${p}play <song>`, 'Search YouTube and download audio'],
            [`${p}playdoc <song>`, 'Download YouTube audio as an MP3 file'],
            [`${p}sticker`, 'Convert an image or video into a sticker'],
            [`${p}take <name>`, 'Change sticker pack/author metadata'],
            [`${p}oncv`, 'Retrieve replied view-once media'],
            [`${p}aonc`, 'Alias for view-once media retrieval'],
        ]],
        ['GROUP', [
            [`${p}tagall`, 'Mention all group members by displayed name'],
            [`${p}hidetag`, 'Mention all members without displaying the tags'],
            [`${p}kick @user`, 'Remove a member from the group'],
            [`${p}add <number>`, 'Add a number to the group'],
            [`${p}promote @user`, 'Promote a member to group admin'],
            [`${p}demote @user`, 'Remove a member from group admin'],
            [`${p}mute`, 'Mute the group so only admins can send'],
            [`${p}unmute`, 'Restore normal group messaging'],
            [`${p}warn @user [reason]`, 'Give a group warning'],
            [`${p}warnings @user`, 'View a member warning profile'],
            [`${p}resetwarn @user`, 'Reset a member warning profile'],
            [`${p}welcome on|off [message]`, 'Configure welcome messages'],
            [`${p}goodbye on|off [message]`, 'Configure goodbye messages'],
            [`${p}antilink on|off|warn N|kick`, 'Configure link protection'],
            [`${p}antigm on|off|warn N|kick`, 'Protect against group mentions in Status'],
            [`${p}antibadword on|off`, 'Enable or disable bad-word protection'],
            [`${p}addbadword <word>`, 'Add a blocked word'],
            [`${p}delbadword <word>`, 'Remove a blocked word'],
            [`${p}badwordlist`, 'View blocked words'],
            [`${p}antispam on|off`, 'Enable or disable spam protection'],
            [`${p}antitag on|off`, 'Enable or disable mention protection'],
        ]],
        ['PLAYGROUND', [
            [`${p}bmenu`, 'Open the dedicated Battleversia menu'],
            [`${p}bv start <mode>`, 'Create a Battleversia match and choose one of 8 modes'],
            [`${p}bv join`, 'Join the active Battleversia lobby'],
            [`${p}bv begin`, 'Begin the Battleversia auction (authorized starter/admin)'],
            [`${p}bv bid <amount>`, 'Place a Battleversia auction bid'],
            [`${p}bv h ⟡ ${p}h`, 'Quick-bid during an auction'],
            [`${p}bv pass ⟡ ${p}pass ⟡ ${p}p`, 'Pass on the current auction character'],
            [`${p}bv pause ⟡ ${p}bv resume`, 'Pause or resume an active match'],
            [`${p}bv status ⟡ ${p}bv wallets`, 'View active match state and game wallets'],
            [`${p}bv end`, 'End an active Battleversia match'],
            [`${p}bv profile ⟡ ${p}bvname`, 'View or set your Battleversia profile/moniker'],
            [`${p}bal ⟡ ${p}bvrank ⟡ ${p}vb`, 'View Bank Versia balance and global rankings'],
            [`${p}gift @user <amount>`, 'Transfer Yons from your Bank Versia balance to another Battleversia player'],
            [`${p}bvh <anime|marvel|dc|overall>`, 'View Battleversia character hierarchy'],
            [`${p}bvm ⟡ ${p}bvmarket`, 'Open the character market'],
            [`${p}bv compare <A> | <B>`, 'Compare characters using canonical score, ability tags and effective power'],
            [`${p}bv matchup history <character>`, 'View recorded character matchup history'],
            [`${p}bv power <character>`, 'View a character Power Index'],
            [`${p}bv forms <character>`, 'View known forms and their hierarchy scores'],
            [`${p}bv synergy`, 'Calculate collection tag synergy'],
            [`${p}bv battle <replay-id>`, 'View a persistent Battleversia battle replay'],
            [`${p}bv ranked start <mode>`, 'Start a rating-enabled ranked match'],
            [`${p}bv casual start <mode>`, 'Start a match without rating changes'],
            [`${p}bv draft start <mode>`, 'Start a no-bid strategic character draft'],
            [`${p}bv draft join`, 'Join an open character draft'],
            [`${p}bv draft begin`, 'Begin the draft (starter/admin)'],
            [`${p}bv draft pick <character>`, 'Pick an available character on your turn'],
            [`${p}bv draft status`, 'View the active draft'],
            [`${p}gs ⟡ ${p}bvt`, 'Browse Game Servers and Tournament Master Servers'],
            [`${p}gs <name> commands`, 'View approved commands for a custom Game Server'],
            [`${p}gs <name> proposals`, 'Review commands intelligently proposed from the Game Server description/rules'],
            [`${p}claim <id>`, 'Claim an available Battleversia airdrop'],
            [`${p}WCG [easy|hard]`, 'Open a 60-second Word Chain Game lobby'],
            [`${p}wcg bot`, 'Start a WCG lobby with Yonder as an automated opponent'],
            [`${p}join`, 'Join an open WCG lobby before the game begins'],
            [`${p}join self`, 'Bot account joins WCG as a manually controlled player'],
            [`${p}join bot`, 'Bot account joins WCG as an automated player'],
            [`${p}wcg leave`, 'Leave the WCG lobby during the 60-second join window'],
            [`${p}wcg end`, 'End the active WCG (privileged users)'],
            [`${p}wcg settime <seconds> [easy|hard]`, 'Set the WCG turn timer'],
                    ]],
        ['SYSTEM', [
            [`${p}stats ⟡ ${p}wcgstats`, 'View persistent WCG statistics'],
            [`${p}achievements`, 'View WCG achievements'],
            [`${p}leaderboard ⟡ ${p}wcgleaderboard`, 'View global WCG rankings'],
            [`${p}test`, 'Run a basic bot status test'],
        ]],
    ]
    if (includeAdmin) sections.push(['ADMIN', [
        [`${p}add admin @user`, 'Grant a user full bot command access'],
        [`${p}deladmin @user`, 'Remove a user from the admin list'],
        [`${p}admin list`, 'List configured administrators'],
        [`${p}setsudo @user`, 'Add a user to the sudo list'],
        [`${p}delsudo @user`, 'Remove a user from the sudo list'],
        [`${p}sudolist`, 'View the sudo users'],
        [`${p}sudo list`, 'View the sudo users'],
        [`${p}permissions`, 'View the Creator → Admin → Sudo → User hierarchy'],
        [`${p}bv research refresh <character>`, 'Refresh stored research without overwriting canonical score/rank/rarity'],
        [`${p}bc season end <id>`, 'End a season and award its configured champion prize'],
        [`${p}plugin list`, 'List installed plugins'],
        [`${p}plugin add <url> [name]`, 'Install a JavaScript plugin'],
        [`${p}plugin del <name>`, 'Remove an installed plugin'],
        [`${p}public`, 'Enable global public mode'],
        [`${p}private`, 'Enable strict private mode (only sudo/admin/creator/bot commands are answered)'],
        [`${p}start`, 'Bring the bot out of shutdown mode'],
        [`${p}shutdown`, 'Put the bot into shutdown mode'],
        [`${p}restart`, 'Restart the bot process'],
        [`${p}set prefix = <design>`, 'Change the global command prefix'],
        [`${p}set time = <seconds> [easy|hard]`, 'Set the default WCG turn timer'],
        [`${p}set wcgtime = <seconds>`, 'Set Yonder’s automated WCG reply delay (1–19 seconds)'],
        [`${p}wcg config <setting> <value>`, 'Configure WCG for the current group'],
        [`${p}stats ⟡ ${p}wcgstats`, 'View persistent WCG statistics'],
        [`${p}achievements`, 'View earned WCG achievements'],
        [`${p}leaderboard ⟡ ${p}wcgleaderboard`, 'View global WCG rankings'],
        [`${p}wcgconfig <setting> <value>`, 'Configure WCG independently for this group'],
        [`${p}me`, 'Show the current bot-account WhatsApp identifier'],
        [`${p}from`, 'Show the current chat identifier'],
        [`${p}info`, 'Show raw message/system information'],
    ]])
    return `𒆜*Yonder MD — Help*\n> *Go Beyond the Ordinary, Plus Ultra.*\n\n${sections.map(([title, rows]) => `*${title}*\n${rows.map(([cmd, desc]) => `𒆜 ${cmd} ⟡ ${desc}`).join('\n')}`).join('\n\n')}`
}

async function sendMenu(snowi, from, reply, userDisplayName = 'Unknown', includeAdmin = false, help = false) {
    const image = nextMenuImage()
    const caption = help ? helpText(includeAdmin) : menuText(userDisplayName, includeAdmin)
    if (image && fs.existsSync(image)) {
        await snowi.sendMessage(from, { image: fs.readFileSync(image), caption }, { quoted: null })
    } else {
        await reply(caption)
    }
}

function getDisplayNameFromGroup(participants, jid, fallback = '') {
    const p = (participants || []).find(v => {
        try { return areJidsSameUser(normalizeJid(v.id), normalizeJid(jid)) } catch { return v.id === jid }
    })
    return displayNameForParticipant(p, fallback || numberOf(jid))
}

function getTargetJids(mentioned, text, quoted, snowi, quotedParticipant = '') {
    const result = [...mentioned]
    if (!result.length && quotedParticipant) result.push(quotedParticipant)
    if (!result.length && quoted?.participant) result.push(quoted.participant)
    if (!result.length && /^\d{6,20}$/.test(String(text).trim())) result.push(String(text).trim() + '@s.whatsapp.net')
    return [...new Set(result.map(j => normalizeJid(j, snowi)).filter(Boolean))]
}

async function requireGroup(from, x, reply) {
    if (!x.isGroup) {
        await reply('This command can only be used in a group chat.')
        return false
    }
    return true
}

async function requireAdmin(isAdmins, isOwnerUser, reply) {
    if (!isAdmins && !isOwnerUser) {
        await reply('Only group admins can use this command.')
        return false
    }
    return true
}

async function requireBotAdmin(isBotAdmins, reply) {
    if (!isBotAdmins) {
        await reply('I need to be a group admin to do that.')
        return false
    }
    return true
}

async function deleteMessage(snowi, from, key) {
    try { await snowi.sendMessage(from, { delete: key }) } catch {}
}

async function loadPlugins() {
    if (!fs.existsSync(PLUGIN_DIR)) return
    for (const file of fs.readdirSync(PLUGIN_DIR).filter(f => f.endsWith('.js'))) {
        const full = path.join(PLUGIN_DIR, file)
        try {
            delete require.cache[require.resolve(full)]
            const plugin = require(full)
            const commands = plugin?.commands || {}
            for (const [name, handler] of Object.entries(commands)) {
                if (typeof handler === 'function') loadedPlugins.set(name.toLowerCase(), { handler, file })
            }
        } catch (e) {
            console.log(`Plugin load failed: ${file}`, e.message)
        }
    }
}

loadPlugins().catch(() => {})

let wcgDictionarySet
let wcgDictionaryList
function getWcgDictionary() {
    if (wcgDictionarySet) return { set: wcgDictionarySet, list: wcgDictionaryList }
    const set = new Set()
    try {
        const words = getWcgDictionary().list
        if (Array.isArray(words)) {
            for (const word of words) {
                const w = String(word || '').toLowerCase()
                if (/^[a-z]+$/.test(w)) set.add(w)
            }
        }
    } catch (e) { console.error('[wcg:dictionary:base]', e?.message || e) }
    try {
        const extendedPath = path.join(DATA_DIR, 'wcg-extended-dictionary.json')
        const words = JSON.parse(fs.readFileSync(extendedPath, 'utf8'))
        if (Array.isArray(words)) {
            for (const word of words) {
                const w = String(word || '').toLowerCase()
                if (/^[a-z]+$/.test(w)) set.add(w)
            }
        }
    } catch (e) { console.error('[wcg:dictionary:extended]', e?.message || e) }
    try {
        const dict = fs.readFileSync('/usr/share/dict/words', 'utf8').split(/\r?\n/)
        for (const word of dict) {
            const w = String(word || '').trim().toLowerCase()
            if (/^[a-z]+$/.test(w)) set.add(w)
        }
    } catch {}
    wcgDictionarySet = set
    wcgDictionaryList = [...set]
    console.log(`[wcg] Loaded ${wcgDictionaryList.length} recognized words.`)
    return { set: wcgDictionarySet, list: wcgDictionaryList }
}

function isRecognizedWord(word) {
    const w = String(word || '').toLowerCase()
    if (!/^[a-z]+$/.test(w)) return false
    return getWcgDictionary().set.has(w)
}

const wcgGames = {
    get: chat => gameRegistry.get(chat, 'wcg'),
    set: (chat, game) => gameRegistry.set(chat, game, 'wcg'),
    has: chat => gameRegistry.has(chat, 'wcg'),
    delete: chat => gameRegistry.delete(chat, 'wcg')
}
const wcgConfig = { easy: Number(db.system?.wcgTimes?.easy) || 30, hard: Number(db.system?.wcgTimes?.hard) || 25 }
const WCG_ALLOWED_TIMES = new Set([20,25,30,35,40,45,50])

function wcgKey(from) { return String(from || '') }
function wcgComplexity(word) {
    const w = String(word || '').toLowerCase()
    if (!w) return 0
    const rare = (w.match(/[qzxj]/g) || []).length * 4
    const consonants = (w.match(/[^aeiou]/g) || []).length
    const unique = new Set(w).size
    return (w.length * 2) + consonants + unique + rare
}
function wcgMentions(players, currentIndex) {
    if (!players.length) return []
    const current = players[currentIndex]
    const next = players.length > 1 ? players[(currentIndex + 1) % players.length] : null
    return [current, next].filter(Boolean)
}
function wcgDisplayMap(game, snowi) {
    return new Map((game.participants || []).map(p => [normalizeJid(p.id, snowi), p]))
}
function wcgDisplay(game, jid, snowi) {
    const map = wcgDisplayMap(game, snowi)
    return displayNameForParticipant(map.get(normalizeJid(jid, snowi)), numberOf(jid))
}
function wcgTurnText(game, participantsMap) {
    const current = game.players[game.turn]
    const next = game.players.length > 1 ? game.players[(game.turn + 1) % game.players.length] : null
    const display = jid => displayNameForParticipant(participantsMap.get(jid), numberOf(jid))
    return `*WORD CHAIN* ⚡\n𒆜 Game ⫸ IN PLAY 🎮\n𒆜 Players ⫸ ${game.players.length}\n𒆜 Turn ⫸ @${display(current)} 🔥\n𒆜 Next ⫸ ${next ? `@${display(next)} 👀` : '—'}\n𒆜 Letter ⫸ ${game.letter.toUpperCase()} 🔤\n𒆜 Minimum ⫸ ${game.minLength} letters 📏\n𒆜 Difficulty ⫸ ${game.difficulty.toUpperCase()} 💥\n𒆜 Round ⫸ ${game.round}`
}

function wcgStatKey(jid) { return numberOf(jid) || String(jid || '') }
function ensureWcgStat(jid) {
    const key = wcgStatKey(jid)
    if (!db.system.wcgStats[key]) db.system.wcgStats[key] = { wins: 0, losses: 0, words: 0, longest: '', fastestMs: null, streak: 0, bestStreak: 0, games: 0, invalid: 0, achievements: [] }
    const s = db.system.wcgStats[key]
    s.achievements = Array.isArray(s.achievements) ? s.achievements : []
    try { require('./lib/battleversia').syncWcgStatSnapshot(jid, s) } catch {}
    return s
}
function awardWcgAchievement(jid, id) {
    const s = ensureWcgStat(jid)
    if (!s.achievements.includes(id)) s.achievements.push(id)
}
function recordWcgWord(jid, word, responseMs = null) {
    const s = ensureWcgStat(jid)
    s.words += 1
    s.games = Math.max(1, s.games)
    if (!s.longest || word.length > s.longest.length) s.longest = word
    if (Number.isFinite(responseMs) && responseMs >= 0 && (s.fastestMs === null || responseMs < s.fastestMs)) s.fastestMs = responseMs
    if (s.words >= 100) awardWcgAchievement(jid, '100-words')
    if (word.length >= 10) awardWcgAchievement(jid, 'longest-word')
    if (Number.isFinite(responseMs) && responseMs <= 5000) awardWcgAchievement(jid, 'fast-response')
}
function recordWcgGameEnd(game, winner) {
    const participants = [...new Set([...(game.allPlayers || game.players || []), ...(game.eliminated || []).map(x => x.jid)])]
    for (const jid of participants) {
        const s = ensureWcgStat(jid); s.games += 1
        const won = !!winner && areJidsSameUser(jid, winner)
        if (won) { s.wins += 1; s.streak += 1; s.bestStreak = Math.max(s.bestStreak, s.streak); awardWcgAchievement(jid, 'first-win'); if (s.wins >= 10) awardWcgAchievement(jid, '10-wins'); if (s.streak >= 3) awardWcgAchievement(jid, 'perfect-streak') }
        else { s.losses += 1; s.streak = 0 }
    }
    writeJson(DATA_FILE, db)
}
function wcgStatsText(jid, title = 'WCG STATS') {
    const s = ensureWcgStat(jid)
    const total = s.wins + s.losses
    const rate = total ? ((s.wins / total) * 100).toFixed(1) : '0.0'
    const fastest = s.fastestMs === null ? '—' : `${(s.fastestMs / 1000).toFixed(2)}s`
    return `📊 *${title}*\n𒆜 Wins ⫸ ${s.wins}\n𒆜 Losses ⫸ ${s.losses}\n𒆜 Games ⫸ ${s.games}\n𒆜 Words ⫸ ${s.words}\n𒆜 Longest ⫸ ${s.longest || '—'}\n𒆜 Fastest ⫸ ${fastest}\n𒆜 Win Rate ⫸ ${rate}%\n𒆜 Streak ⫸ ${s.streak}\n𒆜 Best Streak ⫸ ${s.bestStreak}\n𒆜 Achievements ⫸ ${s.achievements.length}`
}
function getWcgCategoryWords(category) {
    const key = String(category || 'general').toLowerCase()
    const custom = Array.isArray(db.system.wcgCategories[key]) ? db.system.wcgCategories[key] : []
    return [...new Set(custom.map(w => String(w).toLowerCase().replace(/[^a-z]/g, '')).filter(Boolean))]
}
function wcgLeaderboard(limit = 10) {
    return Object.entries(db.system.wcgStats).map(([jid, s]) => ({ jid, ...s, rate: (s.wins + s.losses) ? s.wins / (s.wins + s.losses) : 0 })).sort((a,b) => b.wins - a.wins || b.words - a.words || b.bestStreak - a.bestStreak).slice(0, limit)
}

function wcgBotJid(snowi) {
    try { return normalizeJid(snowi.user?.id, snowi) } catch { return '' }
}
function wcgBotCanPlay(game, snowi) {
    const bot = wcgBotJid(snowi)
    return !!bot && game.botMode === 'auto' && game.players.some(j => areJidsSameUser(j, bot)) && areJidsSameUser(game.players[game.turn], bot)
}
function wcgBotPickWord(game) {
    try {
        const { list } = getWcgDictionary()
        const letter = game.letter.toLowerCase()
        const categoryWords = game.category && game.category !== 'general' ? getWcgCategoryWords(game.category) : null
        const source = categoryWords?.length ? categoryWords : list
        const matches = source.filter(w => w.length >= game.minLength && /^[a-z]+$/.test(w) && w.startsWith(letter) && !game.used.has(w))
        if (matches.length) return matches[crypto.randomInt(matches.length)].toLowerCase()
    } catch {}
    return null
}
async function wcgBotPlayTurn(snowi, from, game) {
    if (!wcgGames.has(wcgKey(from)) || wcgGames.get(wcgKey(from)) !== game || game.phase !== 'playing' || !wcgBotCanPlay(game, snowi)) return
    const word = wcgBotPickWord(game)
    const bot = wcgBotJid(snowi)
    if (!word) {
        await wcgEliminate(snowi, from, game, bot, 'Yonder could not find a valid word. 🤖⏰')
        return
    }
    game.used.add(word)
    recordWcgWord(bot, word, Math.max(0, Number(game.groupConfig?.botDelay || db.system.wcgBotDelay) * 1000))
    if (!game.longest || word.length > game.longest.word.length) game.longest = { jid: bot, word }
    advanceWcgHardProgression(game)
    const complexity = wcgComplexity(word)
    if (!game.complex || complexity > game.complex.score) game.complex = { jid: bot, word, score: complexity }
    if (game.timer) clearTimeout(game.timer)
    game.timer = null
    const botMessage = await snowi.sendMessage(from, {
        text: word,
        mentions: [bot]
    }, { quoted: null }).catch(() => null)
    if (botMessage?.key) {
        game.botMessageIds.add(botMessage.key.id)
        // React to Yonder's own submitted word exactly as it reacts to a user's valid word.
        await safeReact(snowi, from, botMessage.key, '✅')
    }
    game.turn = (game.turn + 1) % game.players.length
    if (game.turn === 0) nextWcgRound(game)
    await sendWcgTurn(snowi, from, game, game.participants)
}

async function sendWcgTurn(snowi, from, game, participants) {
    if (!wcgGames.has(wcgKey(from)) || wcgGames.get(wcgKey(from)) !== game || game.phase !== 'playing') return
    const map = new Map((participants || []).map(p => [normalizeJid(p.id, snowi), p]))
    const mentions = wcgMentions(game.players, game.turn)
    const opening = game.botOpeningWord && !game.openingAnnounced ? `🤖 *Yonder opens the chain!* ⚡\n𒆜 Word ⫸ ${game.botOpeningWord}\n𒆜 Recognition ⫸ Valid English word ✅\n\n` : ''
    game.openingAnnounced = true
    const text = opening + wcgTurnText(game, map)
    await snowi.sendMessage(from, { text, mentions }, { quoted: null })
    if (game.timer) clearTimeout(game.timer)
    const token = game.sessionId
    const current = game.players[game.turn]
    game.responseStartedAt = Date.now()
    game.timer = setTimeout(() => {
        const active = wcgGames.get(wcgKey(from))
        if (active !== game || active.sessionId !== token || active.phase !== 'playing' || !areJidsSameUser(active.players[active.turn], current)) return
        wcgEliminate(snowi, from, game, current, 'Time expired. ⏰').catch(() => {})
    }, game.time * 1000)
    if (wcgBotCanPlay(game, snowi)) {
        const delay = Math.max(1, Number((game.groupConfig?.botDelay) || db.system.wcgBotDelay) || 7) * 1000
        setTimeout(() => wcgBotPlayTurn(snowi, from, game).catch(() => {}), delay)
    }
}
async function wcgEndGame(snowi, from, game, reason = 'completed') {
    if (game.timer) clearTimeout(game.timer)
    if (game.lobbyTimer) clearTimeout(game.lobbyTimer)
    if (game.lobbyNoticeTimer) clearTimeout(game.lobbyNoticeTimer)
    game.timer = null
    game.lobbyTimer = null
    game.lobbyNoticeTimer = null
    if (wcgGames.get(wcgKey(from)) === game) wcgGames.delete(wcgKey(from))
    const map = wcgDisplayMap(game, snowi)
    const dn = jid => displayNameForParticipant(map.get(normalizeJid(jid, snowi)), numberOf(jid))
    const winner = game.players.length === 1 ? game.players[0] : null
    if (game.startedAt && reason !== 'not-enough' && reason !== 'manual') recordWcgGameEnd(game, winner)
    const mentions = [...new Set([winner, game.longest?.jid, game.complex?.jid].filter(Boolean))]
    let text = reason === 'not-enough'
        ? '*WORD CHAIN* 🛑\n𒆜 Game ⫸ ENDED\n𒆜 Reason ⫸ Not enough players joined the lobby. 😭'
        : reason === 'manual'
            ? '*WORD CHAIN* 🛑\n𒆜 Game ⫸ ENDED\n𒆜 Reason ⫸ Game ended by a privileged user. 🫡'
            : `*WORD CHAIN CHAMPION* 🏆🔥\n𒆜 Winner ⫸ ${winner ? `@${dn(winner)} 👑` : 'No winner'}\n𒆜 Players Out ⫸ ${game.eliminated.length}\n𒆜 Longest ⫸ ${game.longest ? `@${dn(game.longest.jid)} — ${game.longest.word} 📚` : '—'}\n𒆜 Most Complex ⫸ ${game.complex ? `@${dn(game.complex.jid)} — ${game.complex.word} 🧠` : '—'}\n\n🎉 GG! The chain has spoken.`
    await snowi.sendMessage(from, { text, mentions }, { quoted: null }).catch(() => {})
}
async function wcgEliminate(snowi, from, game, jid, reason) {
    if (wcgGames.get(wcgKey(from)) !== game || game.phase !== 'playing' || !game.players.includes(jid)) return
    if (game.timer) clearTimeout(game.timer)
    game.timer = null
    const map = wcgDisplayMap(game, snowi)
    const name = displayNameForParticipant(map.get(normalizeJid(jid, snowi)), numberOf(jid))
    game.players = game.players.filter(p => p !== jid)
    game.eliminated.push({ jid, reason })
    if (game.players.length <= 1) {
        await snowi.sendMessage(from, { text: `😂💀 @${name} is OUT of the Word Chain!\n𒆜 Reason ⫸ ${reason}\n𒆜 Status ⫸ Eliminated ❌\n\n🏁 No more dodging letters for you!`, mentions: [jid] }, { quoted: null }).catch(() => {})
        await wcgEndGame(snowi, from, game)
        return
    }
    if (game.turn >= game.players.length) game.turn = 0
    const next = game.players[game.turn]
    const nextName = displayNameForParticipant(map.get(normalizeJid(next, snowi)), numberOf(next))
    nextWcgLetter(game)
    const turnText = wcgTurnText(game, map)
    const turnMentions = wcgMentions(game.players, game.turn)
    await snowi.sendMessage(from, { text: `😂💀 @${name} is OUT of the game!\n𒆜 Reason ⫸ ${reason}\n𒆜 Status ⫸ Eliminated ❌\n\n⚔️ @${nextName}, your turn. Don't join them! 😭🔥\n\n${turnText}`, mentions: [...new Set([jid, ...turnMentions])] }, { quoted: null }).catch(() => {})
    if (game.timer) clearTimeout(game.timer)
    const token = game.sessionId
    const current = game.players[game.turn]
    game.responseStartedAt = Date.now()
    game.timer = setTimeout(() => {
        const active = wcgGames.get(wcgKey(from))
        if (active !== game || active.sessionId !== token || active.phase !== 'playing' || !areJidsSameUser(active.players[active.turn], current)) return
        wcgEliminate(snowi, from, game, current, 'Time expired. ⏰').catch(() => {})
    }, game.time * 1000)
}
function nextWcgRound(game) {
    game.round += 1
    if (game.difficulty !== 'hard') game.minLength += 1
    game.letter = String.fromCharCode(97 + crypto.randomInt(26))
}
function advanceWcgHardProgression(game) {
    if (game.difficulty !== 'hard') return
    game.hardSubmissions = Number(game.hardSubmissions || 0) + 1
    // Every 5 valid submissions the next player gets words exactly one
    // letter longer. The player order is never changed by this progression.
    game.minLength = 4 + Math.floor(game.hardSubmissions / 5)
}
function nextWcgLetter(game) {
    game.letter = String.fromCharCode(97 + crypto.randomInt(26))
}
function wcgOpeningWord(game) {
    try {
        const words = getWcgDictionary().list
        const matches = Array.isArray(words)
            ? words.filter(w => typeof w === 'string' && w.length >= game.minLength && /^[a-z]+$/i.test(w) && w.toLowerCase().startsWith(game.letter.toLowerCase()))
            : []
        if (matches.length) return matches[crypto.randomInt(matches.length)].toLowerCase()
    } catch {}
    return null
}

async function wcgRemoveLobbyPlayer(snowi, from, game, jid) {
    if (wcgGames.get(wcgKey(from)) !== game || game.phase !== 'lobby') return false
    const index = game.players.findIndex(p => { try { return areJidsSameUser(p, jid) } catch { return p === jid } })
    if (index === -1) return false
    const name = wcgDisplay(game, jid, snowi)
    const wasBot = areJidsSameUser(jid, wcgBotJid(snowi))
    game.players.splice(index, 1)
    if (wasBot) game.botMode = 'none'
    await snowi.sendMessage(from, {
        text: `🚪 *WCG PLAYER LEFT*\n𒆜 @${name} has left the WCG lobby.\n𒆜 Players ⫸ ${game.players.length}\n𒆜 Lobby ⫸ OPEN ⏳\n\nThe 60-second lobby continues.`,
        mentions: [jid]
    }, { quoted: null }).catch(() => {})
    return true
}

async function startWcgAfterLobby(snowi, from, game) {
    if (wcgGames.get(wcgKey(from)) !== game || game.phase !== 'lobby' || game.players.length < 2) return false
    if (game.lobbyTimer) clearTimeout(game.lobbyTimer)
    game.lobbyTimer = null
    game.phase = 'playing'
    game.startedAt = Date.now()
    game.turn = 0
    const openingWord = wcgOpeningWord(game)
    if (openingWord) {
        game.used.add(openingWord)
        game.botOpeningWord = openingWord
    }
    await sendWcgTurn(snowi, from, game, game.participants)
    return true
}


function findGroupJidsDeep(value, out = new Set(), seen = new Set()) {
    if (!value || typeof value !== 'object' || seen.has(value)) return out
    seen.add(value)
    if (Array.isArray(value)) { for (const v of value) findGroupJidsDeep(v, out, seen); return out }
    for (const [k, v] of Object.entries(value)) {
        if (typeof v === 'string' && /@g\.us$/i.test(v)) out.add(v)
        else if (v && typeof v === 'object') findGroupJidsDeep(v, out, seen)
    }
    return out
}

async function handleStatusAntiGM(snowi, m, sender) {
    const anti = db.system.antigm
    if (!anti?.enabled || m?.key?.remoteJid !== 'status@broadcast' || m?.key?.fromMe) return false
    const mentionedGroups = [...findGroupJidsDeep(m.message)]
    if (!mentionedGroups.length) return false
    for (const groupJid of mentionedGroups) {
        const metadata = await snowi.groupMetadata(groupJid).catch(() => null)
        if (!metadata) continue
        const participant = metadata.participants?.find(p => {
            try { return areJidsSameUser(normalizeJid(p.id, snowi), normalizeJid(sender, snowi)) } catch { return false }
        })
        if (!participant) continue
        const admin = participant.admin === 'admin' || participant.admin === 'superadmin'
        if (admin) continue
        try { await snowi.sendMessage('status@broadcast', { delete: m.key }) } catch {}
        if (anti.mode === 'kick') {
            await snowi.groupParticipantsUpdate(groupJid, [sender], 'remove').catch(() => {})
        } else {
            anti.violations[sender] = Number(anti.violations[sender] || 0) + 1
            const n = anti.violations[sender]
            writeJson(DATA_FILE, db)
            if (n >= Number(anti.threshold || 3)) {
                await snowi.groupParticipantsUpdate(groupJid, [sender], 'remove').catch(() => {})
                delete anti.violations[sender]
                writeJson(DATA_FILE, db)
            }
        }
    }
    return true
}


// ─── YouTube play helpers ────────────────────────────────────────────────────

function withTimeout(promise, ms, label = 'operation') {
    return Promise.race([
        Promise.resolve(promise),
        new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timed out`)), ms)),
    ])
}

function parsePlayDurationSeconds(value) {
    const parts = String(value || '').trim().split(':').map(Number)
    if (!parts.length || parts.some(v => !Number.isFinite(v))) return 0
    if (parts.length === 2) return Math.max(0, Math.round(parts[0] * 60 + parts[1]))
    if (parts.length === 3) return Math.max(0, Math.round(parts[0] * 3600 + parts[1] * 60 + parts[2]))
    return 0
}

async function sendPlayBanner(sock, chatId, message, meta, action) {
    const caption = [
        `🎵 *${meta.title}*`,
        meta.author ? `👤 ${meta.author}` : '',
        meta.duration ? `⏱️ ${meta.duration}` : '',
        meta.views ? `👁️ ${meta.views} views` : '',
        '',
        `⬇️ _${action}_`,
    ].filter(Boolean).join('\n')
    if (meta.thumbnail) {
        try {
            return await sock.sendMessage(chatId, { image: { url: meta.thumbnail }, caption }, { quoted: message })
        } catch {}
    }
    return sock.sendMessage(chatId, { text: caption }, { quoted: message })
}

function pickPlayDownload(result) {
    if (!result) return null
    return result.audio || result.download_url || result.audio_url
        || result.url || result.link || result.mp3 || null
}

let playScraper
function getPlayScraper() {
    if (!playScraper) playScraper = require('ruhend-scraper')
    return playScraper
}

async function ytSearchForPlay(input) {
    const yts = require('yt-search')
    if (/youtube\.com|youtu\.be/i.test(input)) {
        const idMatch = String(input).match(/(?:v=|youtu\.be\/|shorts\/|embed\/)([A-Za-z0-9_-]{6,})/i)
        const videoId = idMatch?.[1] || ''
        return {
            url: input,
            title: input,
            thumbnail: videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null,
            duration: '',
            author: '',
            views: '',
        }
    }
    const { videos } = await withTimeout(yts(input), 5000, 'YouTube search')
    if (!videos?.length) throw new Error('No YouTube results found.')
    const v = videos[0]
    return {
        url: v.url,
        title: v.title,
        thumbnail: v.thumbnail || v.image || null,
        duration: v.timestamp || '',
        author: v.author?.name || '',
        views: v.views ? Number(v.views).toLocaleString() : '',
    }
}

async function resolvePlayAudioUrl(ytUrl, timeoutMs = 14000) {
    const started = Date.now()
    const remaining = () => Math.max(1000, timeoutMs - (Date.now() - started))
    const attempts = []

    try {
        const { ytmp3 } = getPlayScraper()
        if (typeof ytmp3 === 'function') {
            attempts.push(withTimeout(
                ytmp3(ytUrl).then(data => ({
                    dl: data?.audio || data?.download_url || data?.url || null,
                    title: data?.title || ytUrl,
                })),
                remaining(),
                'Ruhend audio download'
            ))
        }
    } catch (e) {
        console.error('[play:ruhend]', e?.message || e)
    }

    const endpoints = [
        () => giftedGet('/download/ytaudio', { url: ytUrl }, Math.min(12000, remaining())),
        () => giftedGet('/download/ytmp3', { url: ytUrl, quality: '128kbps' }, Math.min(12000, remaining())),
        () => giftedGet('/download/savetubemp3', { url: ytUrl }, Math.min(12000, remaining())),
    ]
    for (const ep of endpoints) {
        attempts.push(withTimeout(
            ep().then(data => ({
                dl: pickPlayDownload(data?.result),
                title: data?.result?.title || ytUrl,
            })),
            remaining(),
            'Gifted audio download'
        ))
    }

    const results = await Promise.allSettled(attempts)
    for (const result of results) {
        if (result.status === 'fulfilled' && result.value?.dl) return result.value
    }
    throw new Error('All audio endpoints failed or timed out')
}

function playInfoText(meta, title) {
    return [
        `🎵 ${title || meta.title || 'Yonder Audio'}`,
        meta.author ? `👤 ${meta.author}` : '',
        meta.duration ? `⏱️ ${meta.duration}` : '',
        meta.views ? `👁️ ${meta.views} views` : '',
    ].filter(Boolean).join(' • ')
}

async function fetchPlayThumbnail(url, timeoutMs = 5000) {
    if (!url || !/^https?:\/\//i.test(String(url))) return null
    try { return await withTimeout(mediaToBuffer(String(url)), timeoutMs, 'Song cover download') }
    catch (e) { console.error('[play:thumbnail]', e?.message || e); return null }
}

async function sendPlayCover(snowi, from, message, ytMeta, title, thumbnailBuffer) {
    if (!Buffer.isBuffer(thumbnailBuffer) || thumbnailBuffer.length < 256) return false
    try {
        await snowi.sendMessage(from, { image: thumbnailBuffer, caption: playInfoText(ytMeta, title) }, { quoted: message })
        return true
    } catch (e) { console.error('[play:cover]', e?.message || e); return false }
}

async function sendPlayAudio(snowi, from, message, ytMeta, audioBuffer, title, thumbnailBuffer = null) {
    const safeTitle = String(title || ytMeta.title || 'Yonder Audio')
        .replace(/[\\/:*?"<>|]/g, '')
        .trim()
        .slice(0, 80) || 'Yonder Audio'
    const seconds = parsePlayDurationSeconds(ytMeta.duration)
    const info = playInfoText(ytMeta, title)

    // WhatsApp's AudioMessage has no native caption field. Keep the song info
    // attached to the SAME audio message through contextInfo rather than
    // sending a second banner message that can arrive later.
    return snowi.sendMessage(from, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false,
        ...(seconds > 0 ? { seconds } : {}),
        contextInfo: {
            externalAdReply: {
                title: safeTitle,
                body: info,
                mediaType: 2,
                thumbnailUrl: ytMeta.thumbnail || undefined,
                ...(Buffer.isBuffer(thumbnailBuffer) ? { thumbnail: thumbnailBuffer } : {}),
                sourceUrl: ytMeta.url || undefined,
                showAdAttribution: false,
                renderLargerThumbnail: false,
            },
        },
    }, {
        quoted: message,
        mediaUploadTimeoutMs: 30000,
    })
}

module.exports = async (snowi, m, chatUpdate, store) => {
    try {
        let x = {}
        x.id = m.key.id
        x.isBaileys = x.id.startsWith('BAE5') && x.id.length === 16
        x.chat = m.key.remoteJid
        x.fromMe = m.key.fromMe
        x.isGroup = x.chat?.endsWith('@g.us') || false

        if ((m.key?.participant?.endsWith('@lid')) && (m.key?.participant === snowi.user.lid)) x.sender = snowi.user.lid
        else x.sender = snowi.decodeJid(x.fromMe && snowi.user.id || x.participant || m.key.participant || x.chat || '')
        if (x.isGroup) x.participant = snowi.decodeJid(m.key.participant) || ''

        function getTypeM(message) {
            const type = Object.keys(message || {})
            return (!['senderKeyDistributionMessage', 'messageContextInfo'].includes(type[0]) && type[0]) || (type.length >= 3 && type[1] !== 'messageContextInfo' && type[1]) || type[type.length - 1] || ''
        }

        x.mtype = getTypeM(m.message)
        x.msg = x.mtype === 'viewOnceMessage' ? m.message[x.mtype].message[getTypeM(m.message[x.mtype].message)] : m.message[x.mtype]
        x.text = x?.msg?.text || x?.msg?.caption || m?.message?.conversation || x?.msg?.contentText || x?.msg?.selectedDisplayText || x?.msg?.title || ''

        const info = { key: m.key, message: m.message }
        const from = info.key.remoteJid
        const statusSender = info.key.participant || info.key.remoteJid
        if (await handleStatusAntiGM(snowi, m, statusSender)) return
        let interactiveId = ''
        if (x.mtype === 'interactiveResponseMessage') {
            try { interactiveId = JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id || '' } catch {}
        }
        const body = x.mtype === 'interactiveResponseMessage' ? interactiveId
            : x.mtype === 'conversation' ? m.message.conversation
            : x.mtype === 'deviceSentMessage' ? m.message.extendedTextMessage?.text
            : x.mtype === 'imageMessage' ? m.message.imageMessage?.caption
            : x.mtype === 'videoMessage' ? m.message.videoMessage?.caption
            : x.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage?.text
            : x.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage?.selectedButtonId
            : x.mtype === 'listResponseMessage' ? m.message.listResponseMessage?.singleSelectReply?.selectedRowId
            : x.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage?.selectedId
            : x.text || ''

        const quotedMsg = getQuotedMessage(info)
        const quotedParticipant = getQuotedParticipant(info, snowi)
        const bardy = body || ''
        const isInternal = info.key.id === 'INTERNAL-CMD'
        const currentPrefix = getPrefix()
        const prefix = isInternal ? '' : (bardy.startsWith(currentPrefix) ? currentPrefix : '')
        const isCmd = isInternal || !!prefix
        // The bot account may intentionally issue commands itself, so fromMe
        // messages that begin with the active prefix must still be parsed.
        // During a WCG where the bot is in self/manual mode, its ordinary word
        // must also reach the WCG validator. Other bot messages remain ignored.
        const incomingWcg = wcgGames.get(wcgKey(from))
        const botSelfInWcg = !!incomingWcg && incomingWcg.phase === 'playing' && incomingWcg.botMode === 'self' && incomingWcg.players.some(j => {
            try { return areJidsSameUser(j, normalizeJid(snowi.user?.id, snowi)) } catch { return false }
        })
        if (info.key?.fromMe && !isInternal && !isCmd && !botSelfInWcg) return
        if (!isCmd && !x.isGroup) return
        const commandBody = isInternal ? bardy : bardy.slice(prefix.length)
        const command = commandBody.trim().split(/\s+/).shift().toLowerCase()
        const args = commandBody.trim().split(/\s+/).slice(1)
        const text = args.join(' ')
        const q = text
        const sender = info.key.fromMe ? (snowi.user.id.split(':')[0] + '@s.whatsapp.net' || snowi.user.id) : (info.key.participant || info.key.remoteJid)
        const botNumber = await snowi.decodeJid(snowi.user.id)
        const senderNumber = numberOf(sender)
        const isOwnerUser = isOwner(sender, snowi, info.key.fromMe, x.sender, info.key.participant, info.key.participantAlt, info.key.remoteJid, info.key.remoteJidAlt, m.key?.participant, m.key?.participantAlt, m.key?.remoteJid, m.key?.remoteJidAlt) || isInternal
        const isSudo = db.sudo.some(j => areJidsSameUser(j, sender))
        const isAdminUser = isAdmin(sender, snowi)
        const isPrivileged = isOwnerUser || isSudo || isAdminUser
        const pushname = m.pushName || senderNumber
        const isBot = !!info.key.fromMe
        m.sender = x.sender

        // Persistent global bot state: shutdown blocks everyone except creator/bot/admin.
        if (db.system.shutdown && !isBot && !isOwnerUser && !isAdminUser && !isInternal) return
        const isPublicCommand = PUBLIC_COMMANDS.has(command)
        const activeWcgGame = wcgGames.get(wcgKey(from))
        const activeWcgLobby = activeWcgGame?.phase === 'lobby' && ((command === 'join') || (command === 'wcg' && String(args[0] || '').toLowerCase() === 'leave'))
        const activeWcgPlayerMessage = !!activeWcgGame && activeWcgGame.phase === 'playing' && !isCmd && activeWcgGame.players.some(j => { try { return areJidsSameUser(j, normalizeJid(sender, snowi)) } catch { return false } })
        let activeBvLobby = false, activeBvPlayerCommand = false, activeGsPlayerCommand = false
        try {
            const bvStore = require('./lib/battleversia').getStore()
            const bvRows = bvStore.db.prepare("SELECT game_id,phase FROM bv_games WHERE group_jid=? AND phase IN ('LOBBY','AUCTION','PAUSED','ROUND_RESULT') ORDER BY created_at DESC LIMIT 1").all(from)
            const gsRows = bvStore.db.prepare("SELECT * FROM bv_game_servers WHERE status IN ('OPEN','RUNNING')").all()
            for (const gs of gsRows) {
                if (!bvStore.db.prepare('SELECT 1 FROM bv_gs_players WHERE server_id=? AND jid=?').get(gs.server_id, normalizeJid(sender, snowi))) continue
                let cfg={}; try{cfg=JSON.parse(gs.config_json||'{}')}catch{}
                const defs=Array.isArray(cfg.approved_commands)?cfg.approved_commands:[]
                if(defs.some(d=>String(d.name||'').toLowerCase()===String(command).toLowerCase() || (Array.isArray(d.aliases)&&d.aliases.map(x=>String(x).toLowerCase()).includes(String(command).toLowerCase())))){ activeGsPlayerCommand=true; break }
            }
            const bvGame = bvRows[0]
            if (bvGame) {
                activeBvLobby = bvGame.phase === 'LOBBY' && ['bv','h'].includes(command) && (command === 'h' || String(args[0]||'').toLowerCase() === 'join')
                if (['bv','h','pass','p'].includes(command)) {
                    activeBvPlayerCommand = !!bvStore.db.prepare('SELECT 1 FROM bv_game_players WHERE game_id=? AND jid=?').get(bvGame.game_id, normalizeJid(sender, snowi))
                }
            }
        } catch {}
        if (!isInternal && !isOwnerUser && !isSudo && !isAdminUser && db.system.mode === 'private') {
            // Private mode is strictly privileged-only. Ordinary users are silent.
            return
        }
        if (isCmd && !isInternal && !isOwnerUser && !isSudo && !isAdminUser && db.system.mode === 'public' && !isPublicCommand && !activeWcgLobby && !activeGsPlayerCommand) return
        if (isCmd && command) {
            db.system.commandCount = Number(db.system.commandCount || 0) + 1
            writeJson(DATA_FILE, db)
        }

        const groupMetadata = x.isGroup ? await snowi.groupMetadata(from).catch(() => null) : null
        const groupName = x.isGroup ? groupMetadata?.subject || '' : ''
        const participants = x.isGroup ? groupMetadata?.participants || [] : []
        const groupAdmins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => normalizeJid(p.id, snowi))
        const sameUser = (a, b) => {
            try { return !!a && !!b && areJidsSameUser(a, b) } catch { return a === b }
        }
        const botLid = normalizeJid(snowi.user.lid, snowi)
        const normalizedBot = normalizeJid(botNumber, snowi)
        const normalizedSender = normalizeJid(m.sender, snowi)
        const isBotAdmins = x.isGroup ? groupAdmins.some(j => sameUser(j, normalizedBot) || sameUser(j, botLid)) : false
        const isAdmins = x.isGroup ? groupAdmins.some(j => sameUser(j, normalizedSender) || sameUser(j, m.key?.participant)) : false
        const mentionxs = getMentioned(info, x)
        const settingsPath = path.join(__dirname, 'dev', 'setting.js')
        const settings = require(settingsPath)
        const meJid = snowi.user.id.split(':')[0] + '@s.whatsapp.net'

        const reply = async (text, extra = {}) => snowi.sendMessage(from, { text: String(text), mentions: extra.mentions || [sender], ...extra }, { quoted: m }).catch(() => {})
        const quoted = messageFromQuoted(quotedMsg)
        const group = x.isGroup ? getGroupSettings(from) : null

        // WCG is sudo-only in both groups and DMs. Invalid submissions never eliminate a player; only the turn timer can do that.
        const activeWcg = wcgGames.get(wcgKey(from))
        const wcgSender = normalizeJid(sender, snowi)
        if (activeWcg?.botMessageIds?.has(info.key?.id)) {
            activeWcg.botMessageIds.delete(info.key.id)
            return
        }
        if (activeWcg && activeWcg.phase === 'playing' && !isCmd && activeWcg.players.some(j => areJidsSameUser(j, wcgSender))) {
            const currentPlayer = activeWcg.players[activeWcg.turn]
            if (!areJidsSameUser(currentPlayer, wcgSender)) return
            const word = String(bardy || '').trim().toLowerCase()
            // A WCG player's word is always answered as a reply to that exact message,
            // so WhatsApp visibly shows the rejected word beside the reason.
            const rejectWord = async (message) => {
                await snowi.sendMessage(from, {
                    text: `❌ @${wcgDisplay(activeWcg, wcgSender, snowi)} ${message}`,
                    mentions: [wcgSender]
                }, { quoted: m }).catch(() => {})
            }
            if (word.length < activeWcg.minLength) {
                await rejectWord(`your word is too short. It must be at least ${activeWcg.minLength} letters long. 📏`)
                return
            }
            if (!word.startsWith(activeWcg.letter.toLowerCase())) {
                await rejectWord(`wrong starting letter. Your word must start with ${activeWcg.letter.toUpperCase()}. 🔤`)
                return
            }
            if (!isRecognizedWord(word, activeWcg)) {
                activeWcg.invalidAttempts[wcgStatKey(wcgSender)] = Number(activeWcg.invalidAttempts[wcgStatKey(wcgSender)] || 0) + 1
                const bad = activeWcg.invalidAttempts[wcgStatKey(wcgSender)]
                ensureWcgStat(wcgSender).invalid += 1
                writeJson(DATA_FILE, db)
                await rejectWord(`that is not a recognized word. Attempt ${bad}. ${bad >= 2 && activeWcg.groupConfig.invalidWarning !== false ? '⚠️ Repeated invalid attempts will not eliminate you, but stop stalling and find a valid word.' : 'Try again!'} 📖`)
                return
            }
            const responseMs = Date.now() - Number(activeWcg.responseStartedAt || Date.now())
            activeWcg.invalidAttempts[wcgStatKey(wcgSender)] = 0
            recordWcgWord(wcgSender, word, responseMs)
            if (activeWcg.used.has(word)) {
                await rejectWord('that word has already been used. Try another one! 🔁')
                return
            }
            activeWcg.used.add(word)
            if (!activeWcg.longest || word.length > activeWcg.longest.word.length) activeWcg.longest = {jid:wcgSender, word}
            advanceWcgHardProgression(activeWcg)
            const complexity = wcgComplexity(word)
            if (!activeWcg.complex || complexity > activeWcg.complex.score) activeWcg.complex = {jid:wcgSender, word, score:complexity}
            // React directly to the player's submitted message when it is valid.
            // The reaction stays attached to the exact word that advanced the game.
            await safeReact(snowi, from, info.key, '✅')
            activeWcg.turn = (activeWcg.turn + 1) % activeWcg.players.length
            if (activeWcg.turn === 0) nextWcgRound(activeWcg)
            else nextWcgLetter(activeWcg)
            await sendWcgTurn(snowi, from, activeWcg, activeWcg.participants)
            return
        }

        // Automatic moderation runs before commands. The command sender is never filtered by these checks.
        if (!isInternal && x.isGroup && !isBot) {
            const lower = String(bardy).toLowerCase()
            if (group.antibadword && group.badwords.some(w => w && new RegExp(`(^|\\W)${String(w).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?=\\W|$)`, 'iu').test(lower))) {
                if (isBotAdmins) await deleteMessage(snowi, from, info.key)
                await reply('⚠️ Message removed: bad word detected.')
                return
            }
            const anti = db.system.antilink || { enabled:false, mode:'warn', threshold:3, violations:{} }
            if (anti.enabled && /(?:https?:\/\/|www\.|chat\.whatsapp\.com\/|t\.me\/)/i.test(bardy) && !isAdmins) {
                if (isBotAdmins) await deleteMessage(snowi, from, info.key)
                if (anti.mode === 'kick') {
                    if (isBotAdmins) await snowi.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {})
                    return
                }
                anti.violations[sender] = Number(anti.violations[sender] || 0) + 1
                writeJson(DATA_FILE, db)
                const n = anti.violations[sender]
                if (n >= anti.threshold && isBotAdmins) {
                    await snowi.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {})
                    delete anti.violations[sender]
                    writeJson(DATA_FILE, db)
                    const antiName = getDisplayNameFromGroup(participants, sender, numberOf(sender))
                    await reply(`🔗 AntiLink: @${antiName} reached ${anti.threshold}/${anti.threshold} violations and was removed.`, {mentions:[sender]})
                } else { const antiName = getDisplayNameFromGroup(participants, sender, numberOf(sender)); await reply(`🔗 AntiLink: @${antiName} — warning ${n}/${anti.threshold}.`, {mentions:[sender]}) }
                return
            }
            if (group.antitag && mentionxs.length > 0) {
                if (isBotAdmins) await deleteMessage(snowi, from, info.key)
                await reply('🏷️ Mass tagging is disabled in this group.')
                return
            }
            if (group.antispam && bardy.trim()) {
                const key = `${from}:${sender}`
                const now = Date.now()
                const arr = (spamCache.get(key) || []).filter(t => now - t < 8000)
                arr.push(now)
                spamCache.set(key, arr)
                if (arr.length >= 5) {
                    if (isBotAdmins) await deleteMessage(snowi, from, info.key)
                    await reply('🚫 Spam detected. Slow down.')
                    spamCache.set(key, [])
                    return
                }
            }
            if (group.mute && !isAdmins && !isPrivileged) {
                if (isBotAdmins) await deleteMessage(snowi, from, info.key)
                return
            }
        }

        // Dynamic Game Server commands: approved per-server commands are resolved without generating files.
        try {
            const bvDynamic = require('./lib/battleversia')
            const dbv = bvDynamic.getStore()
            const servers = dbv.db.prepare('SELECT * FROM bv_game_servers WHERE status IN (\'OPEN\',\'RUNNING\')').all()
            let matchedServer = null, matchedDef = null
            for (const srv of servers) {
                const joined = dbv.db.prepare('SELECT 1 FROM bv_gs_players WHERE server_id=? AND jid=?').get(srv.server_id, normalizeJid(sender, snowi))
                if (!joined) continue
                const cfg = (()=>{ try{return JSON.parse(srv.config_json||'{}')}catch{return{}} })()
                const defs = Array.isArray(cfg.approved_commands) ? cfg.approved_commands : []
                const def = defs.find(d => String(d.name||'').toLowerCase()===String(command||'').toLowerCase() || (Array.isArray(d.aliases)&&d.aliases.map(x=>String(x).toLowerCase()).includes(String(command||'').toLowerCase())))
                if (def) { matchedServer=srv; matchedDef=def; break }
            }
            if (matchedServer) {
                const dynamicGroupMeta = x.isGroup ? await snowi.groupMetadata(from).catch(() => null) : null
                const bvCtxDynamic = { snowi, m, info, from, sender: normalizeJid(sender, snowi), command: String(command).toLowerCase(), args, q,
                    displayName: displayNameForParticipant((dynamicGroupMeta?.participants || []).find(p => { try { return areJidsSameUser(normalizeJid(p.id, snowi), normalizeJid(sender, snowi)) } catch { return p.id === sender } }), pushname),
                    participants: dynamicGroupMeta?.participants || participants || [], same: (a,b)=>areJidsSameUser(normalizeJid(a,snowi),normalizeJid(b,snowi)), contactName: jid=>store?.contacts?.[jid]?.name||store?.contacts?.[jid]?.notify||'', reply, isOwnerUser, isAdminUser, isSudo: isSudo, isPrivileged, isBot, isGroup:x.isGroup, targets:getTargetJids(mentionxs,q,quotedMsg,snowi,quotedParticipant), mentioned:[...mentionxs], isAdmins, normalizedBot }
                const custom = await bvDynamic.customGameServerCommand(bvCtxDynamic, matchedServer, String(command).toLowerCase(), args)
                if (custom) return
            }
        } catch (e) { console.error('[Battleversia dynamic GS command]', e.message) }

        if (loadedPlugins.has(command)) {
            const plugin = loadedPlugins.get(command)
            await plugin.handler({ snowi, m, chatUpdate, store, x, info, from, sender, args, text, q, reply, quoted, mentionxs, groupMetadata, group, isBot, isOwner: isOwnerUser, isAdmin: isAdminUser, isAdmins, isBotAdmins })
            return
        }

        // Battleversia has its own command engine. It is isolated from WCG state and
        // uses SQLite as its persistent source of truth.
        const battleversiaCommands = new Set(['bmenu','bcmenu','bv','battleversia','bvname','bal','bvrank','vb','bvh','bvmarket','bvm','bvprofile','bvsetsudo','bvdelsudo','bvsudolist','bvaddchar','bc','adp','gsc','gs','bvtcreate','bvt','claim','gift','bvgift','h','pass','p','bvstats','permissions','admin','sudo','bvseason'])
        if (battleversiaCommands.has(command)) {
            const groupMeta = x.isGroup ? await snowi.groupMetadata(from).catch(() => null) : null
            const bvSudo = (() => { try { return require('./lib/battleversia').getStore().getSetting('bv_sudo', []).some(j => { try { return areJidsSameUser(j, sender) } catch { return j === sender } }) } catch { return false } })()
            const bvCtx = {
                snowi, m, info, from, sender: normalizeJid(sender, snowi), command, args, q,
                displayName: displayNameForParticipant((groupMeta?.participants || []).find(p => { try { return areJidsSameUser(normalizeJid(p.id, snowi), normalizeJid(sender, snowi)) } catch { return p.id === sender } }), pushname),
                participants: groupMeta?.participants || participants || [],
                same: (a,b) => areJidsSameUser(normalizeJid(a, snowi), normalizeJid(b, snowi)),
                contactName: jid => store?.contacts?.[jid]?.name || store?.contacts?.[jid]?.notify || '',
                reply, isOwnerUser, isAdminUser, isSudo: isSudo || bvSudo, isPrivileged: isPrivileged || bvSudo,
                isBot, isGroup: x.isGroup,
                targets: getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant),
                mentioned: [...mentionxs],
                isAdmins, normalizedBot
            }
            if (command === 'battleversia') { bvCtx.command = 'bmenu' }
            if (command === 'h') { bvCtx.command = 'bv'; bvCtx.args = ['h']; bvCtx.q = 'h' }
            if (command === 'pass' || command === 'p') { bvCtx.command = 'bv'; bvCtx.args = ['pass']; bvCtx.q = 'pass' }
            await dispatchBattleversia(bvCtx)
            return
        }

        switch (command) {
            case 'set': {
                if (!isPrivileged) return reply('*Yonder Access* ⚡\n𒆜 Privileged users only.')
                const setting = String(args[0] || '').toLowerCase()
                if (setting === 'prefix') {
                    const newPrefix = parsePrefixSetting(q)
                    if (!newPrefix || newPrefix.length > 32 || /[\r\n]/.test(newPrefix)) return reply('Choose a non-empty prefix up to 32 characters, on one line.')
                    db.system.prefix = newPrefix
                    writeJson(DATA_FILE, db)
                    await reply(`*Prefix Updated* ⚡\n𒆜 Prefix ⫸ ${newPrefix}\n𒆜 Status ⫸ Live`)
                    break
                }
                if (setting === 'time') {
                    const raw = q.replace(/^time\s*=\s*/i, '').trim()
                    const n = Number(raw.split(/\s+/)[0])
                    const difficulty = raw.split(/\s+/)[1]?.toLowerCase() || 'hard'
                    if (!WCG_ALLOWED_TIMES.has(n)) return reply('WCG time must be one of: 20, 25, 30, 35, 40, 45, 50 seconds.')
                    const d = ['easy','hard'].includes(difficulty) ? difficulty : 'hard'
                    wcgConfig[d] = n
                    db.system.wcgTimes = wcgConfig
                    writeJson(DATA_FILE, db)
                    return reply(`*WCG Time Updated* ⚡\n𒆜 Difficulty ⫸ ${d.toUpperCase()}\n𒆜 Time ⫸ ${n}s`)
                }
                if (setting === 'wcgtime') {
                    const raw = q.replace(/^wcgtime\s*=\s*/i, '').trim()
                    const n = Number(raw.split(/\s+/)[0])
                    if (!Number.isInteger(n) || n < 1 || n > 19) return reply('WCG bot reply time must be a whole number from 1 to 19 seconds so it always fits inside the shortest WCG turn.')
                    db.system.wcgBotDelay = n
                    writeJson(DATA_FILE, db)
                    return reply(`*WCG Bot Reply Time Updated* 🤖⚡\n𒆜 Delay ⫸ ${n}s\n𒆜 Status ⫸ Persistent`)
                }
                return reply(`Usage: ${getPrefix()}set prefix = <your prefix>\n       ${getPrefix()}set time = <20|25|30|35|40|45|50> [easy|hard]\n       ${getPrefix()}set wcgtime = <1–19>`)
            }

            case 'public':
            case 'private': {
                if (!isPrivileged) return reply('Privileged users only.')
                db.system.mode = command
                writeJson(DATA_FILE, db)
                await reply(`*Yonder Mode* ⚡\n𒆜 Mode ⫸ ${command.toUpperCase()}`)
                break
            }

            case 'shutdown': {
                if (!isBot && !isOwnerUser) return reply('Only the bot account or creator can shut me down.')
                db.system.shutdown = true
                writeJson(DATA_FILE, db)
                await reply(`*Yonder MD* ⚡\n𒆜 Status ⫸ Shutdown\nEntering standby.`)
                break
            }

            case 'start': {
                if (!isBot && !isOwnerUser) return reply('Only the bot account or creator can start me.')
                db.system.shutdown = false
                writeJson(DATA_FILE, db)
                await reply(`*Yonder MD* ⚡\n𒆜 Status ⫸ Online\nIn brightest day, in blackest night, no evil shall escape my sight.\n𒆜 Version ⫸ ${BOT_VERSION}`)
                break
            }
            case 'menu': {
                await sendMenu(snowi, from, reply, x.isGroup ? getDisplayNameFromGroup(participants, sender, pushname) : pushname, isOwnerUser, false)
                break
            }

            case 'help': {
                await sendMenu(snowi, from, reply, x.isGroup ? getDisplayNameFromGroup(participants, sender, pushname) : pushname, isOwnerUser, true)
                break
            }

            case 'ping': {
                const started = process.hrtime.bigint()
                await snowi.sendMessage(from, { text: '𒆜pinging' }, { quoted: null })
                const measuredMs = Number(process.hrtime.bigint() - started) / 1e6
                await snowi.sendMessage(from, { text: `𒆜Pong ${measuredMs.toFixed(0)} ms` }, { quoted: null })
                break
            }
            case 'uptime': {
                await reply(`*Yonder Uptime* ⚡\n𒆜 Uptime ⫸ ${formatUptime(Date.now() - START_TIME)}\n𒆜 Status ⫸ Online`)
                break
            }
            case 'play': {
                if (!q) return reply(`Usage: ${getPrefix()}play <song name or YouTube URL>`)
                const playStarted = Date.now()
                try {
                    await safeReact(snowi, from, info.key, '✅')
                    const ytMeta = await ytSearchForPlay(q)
                    const resolveBudget = Math.max(5000, 22000 - (Date.now() - playStarted))
                    const { dl, title } = await resolvePlayAudioUrl(ytMeta.url, resolveBudget)

                    // Keep the fast audio path and fetch the cover in parallel.
                    const audioPromise = mediaToBuffer(dl)
                    const coverPromise = fetchPlayThumbnail(ytMeta.thumbnail, 5000)
                    const [mp3Buf, coverResult] = await Promise.all([
                        withTimeout(audioPromise, Math.max(5000, 22000 - (Date.now() - playStarted)), 'Audio file download'),
                        coverPromise,
                    ])
                    const coverBuffer = Buffer.isBuffer(coverResult) ? coverResult : null
                    if (!Buffer.isBuffer(mp3Buf) || mp3Buf.length < 1024) throw new Error('Downloaded audio is empty or invalid')

                    // Send the actual cover image so WhatsApp renders it reliably.
                    await sendPlayCover(snowi, from, m, ytMeta, title, coverBuffer)
                    // Keep the existing MP3 delivery path, while also supplying the
                    // cover bytes for clients that render an audio preview thumbnail.
                    await sendPlayAudio(snowi, from, m, ytMeta, mp3Buf, title, coverBuffer)
                } catch (e) {
                    console.error('[play]', e)
                    await reply('❌ Audio download failed or took too long. Try again.')
                }
                break
            }
            case 'playdoc': {
                if (!q) return reply(`Usage: ${getPrefix()}playdoc <song name or YouTube URL>`)
                try {
                    const ytMeta = await ytSearchForPlay(q)
                    await sendPlayBanner(snowi, from, m, ytMeta, 'Downloading audio file…')

                    const { dl, title } = await resolvePlayAudioUrl(ytMeta.url)
                    const buf = await mediaToBuffer(dl)
                    const safeTitle = String(title || ytMeta.title || 'Yonder Audio')
                        .replace(/[\\/:*?"<>|]/g, '')
                        .trim()
                        .slice(0, 80) || 'Yonder Audio'

                    await snowi.sendMessage(from, {
                        document: buf,
                        mimetype: 'audio/mpeg',
                        fileName: `${safeTitle}.mp3`,
                    }, { quoted: m })
                } catch (e) {
                    console.error('[playdoc]', e)
                    await reply('❌ Audio file download failed. Try again.')
                }
                break
            }

            case 'sticker': {
                const source = quoted || (['imageMessage', 'videoMessage'].includes(x.mtype) ? { mtype: x.mtype, msg: x.msg } : null)
                if (!source) return reply(`Reply to an image/video or send ${getPrefix()}sticker with media.`)
                try {
                    const kind = source.mtype === 'videoMessage' ? 'video' : 'image'
                    const buffer = await downloadBuffer(snowi, source)
                    const converted = await makeSticker(buffer, kind)
                    const sticker = await addStickerExif(converted, BOT_NAME, DEVELOPER)
                    await snowi.sendMessage(from, { sticker }, { quoted: m })
                } catch (e) {
                    await reply(`❌ Sticker failed: ${e.message || 'Unable to convert media.'}`)
                }
                break
            }

            case 'take': {
                const source = quoted
                if (!source || source.mtype !== 'stickerMessage') return reply(`Reply to a sticker: ${getPrefix()}take <pack name>|<author>`)
                const [packname = BOT_NAME, author = DEVELOPER] = (q || '').split('|').map(v => v.trim())
                try {
                    const buffer = await downloadBuffer(snowi, source)
                    const sticker = await addStickerExif(buffer, packname || BOT_NAME, author || DEVELOPER)
                    await snowi.sendMessage(from, { sticker }, { quoted: m })
                } catch (e) {
                    await reply(`❌ Take failed: ${e.message || 'Unable to resend sticker.'}`)
                }
                break
            }

            case 'antilink': {
                if (!isPrivileged) return reply('Only privileged users can configure AntiLink.')
                const sub = String(args[0] || '').toLowerCase()
                db.system.antilink = db.system.antilink || { enabled:false, mode:'warn', threshold:3, violations:{} }
                if (sub === 'on' || sub === 'off') db.system.antilink.enabled = sub === 'on'
                else if (sub === 'kick') { db.system.antilink.enabled = true; db.system.antilink.mode = 'kick' }
                else if (sub === 'warn') { const n=Number(args[1]); if (![1,2,3].includes(n)) return reply('AntiLink warning threshold must be 1, 2 or 3.'); db.system.antilink.enabled=true; db.system.antilink.mode='warn'; db.system.antilink.threshold=n }
                else return reply(`${getPrefix()}antilink on|off|warn 1|warn 2|warn 3|kick`)
                writeJson(DATA_FILE, db)
                return reply(`*AntiLink* ⚡\n𒆜 Status ⫸ ${db.system.antilink.enabled?'ON':'OFF'}\n𒆜 Mode ⫸ ${db.system.antilink.mode==='kick'?'KICK':`WARN ${db.system.antilink.threshold}`}`)
            }

            case 'antigm': {
                if (!isPrivileged) return reply('Only privileged users can configure Anti Group Mention.')
                const sub = String(args[0] || '').toLowerCase()
                if (!['on','off','kick','warn'].includes(sub)) return reply(`${getPrefix()}antigm on|off|warn 1|warn 2|warn 3|kick`)
                db.system.antigm = db.system.antigm || { enabled:false, mode:'warn', threshold:3, violations:{} }
                if (sub === 'on' || sub === 'off') db.system.antigm.enabled = sub === 'on'
                if (sub === 'kick') { db.system.antigm.enabled = true; db.system.antigm.mode = 'kick' }
                if (sub === 'warn') { const n = Number(args[1]); if (![1,2,3].includes(n)) return reply('AntiGM warning threshold must be 1, 2 or 3.'); db.system.antigm.enabled = true; db.system.antigm.mode = 'warn'; db.system.antigm.threshold = n }
                writeJson(DATA_FILE, db)
                await reply(`*AntiGM* ⚡\n𒆜 Status ⫸ ${db.system.antigm.enabled ? 'ON' : 'OFF'}\n𒆜 Mode ⫸ ${db.system.antigm.mode === 'kick' ? 'KICK' : `WARN ${db.system.antigm.threshold}` }`)
                break
            }

            case 'wcg': {
                let sub = String(args[0] || 'hard').toLowerCase()
                const key = wcgKey(from)
                if (x.isGroup && !getGroupSettings(from).wcg.games && !isPrivileged) return

                // .wcg bot is intentionally public in public mode so any user can
                // start a private two-player WCG against Yonder. Private mode's
                // global gate still blocks ordinary users from starting games.
                const isBotChallenge = sub === 'bot'
                if (!isPrivileged && !isBotChallenge) return reply('🔒 WCG is a privileged game. Only sudo/admin/creator/bot users can start or manage it.')

                if (sub === 'end') {
                    if (!isPrivileged) return reply('Only a privileged user can end a WCG.')
                    const game = wcgGames.get(key)
                    if (!game) return reply('No WCG is running here.')
                    await wcgEndGame(snowi, from, game, 'manual')
                    return
                }
                if (sub === 'leave') {
                    const game = wcgGames.get(key)
                    if (!game || game.phase !== 'lobby') return reply('There is no open WCG lobby to leave.')
                    const player = normalizeJid(sender, snowi)
                    if (!game.players.some(j => areJidsSameUser(j, player))) return reply('You are not in this WCG lobby.')
                    await wcgRemoveLobbyPlayer(snowi, from, game, player)
                    return
                }
                if (sub === 'config') {
                    if (!isPrivileged) return reply('Only privileged users can configure WCG.')
                    if (!x.isGroup) return reply('Per-group WCG configuration must be used inside a group.')
                    const g = getGroupSettings(from)
                    const setting = String(args[1] || 'show').toLowerCase()
                    const value = String(args[2] || '').toLowerCase()
                    if (setting === 'show') return reply(`⚙️ *WCG GROUP CONFIG*\n𒆜 Difficulty ⫸ ${g.wcg.difficulty}\n𒆜 Timer ⫸ ${g.wcg.time}s\n𒆜 Bot delay ⫸ ${g.wcg.botDelay}s\n𒆜 Mode ⫸ ${g.wcg.mode}\n𒆜 Category ⫸ ${g.wcg.category}\n𒆜 Dictionary ⫸ ${g.wcg.strict ? 'STRICT' : 'BROAD'}\n𒆜 Invalid warning ⫸ ${g.wcg.invalidWarning ? 'ON' : 'OFF'}\n𒆜 Games ⫸ ${g.wcg.games ? 'ON' : 'OFF'}`)
                    if (setting === 'difficulty' && ['easy','hard'].includes(value)) g.wcg.difficulty = value
                    else if (setting === 'time' && WCG_ALLOWED_TIMES.has(Number(value))) g.wcg.time = Number(value)
                    else if (setting === 'botdelay' && Number(value) >= 1 && Number(value) <= 19) g.wcg.botDelay = Number(value)
                    else if (setting === 'mode' && ['classic','blitz','elimination','team','tournament'].includes(value)) g.wcg.mode = value
                    else if (setting === 'category') g.wcg.category = value || 'general'
                    else if (setting === 'dictionary' && ['strict','broad'].includes(value)) g.wcg.strict = value === 'strict'
                    else if (setting === 'warning' && ['on','off'].includes(value)) g.wcg.invalidWarning = value === 'on'
                    else return reply(`Usage: ${getPrefix()}wcg config difficulty <easy|hard> | time <20|25|30|35|40|45|50> | botdelay <1-19> | mode <classic|blitz|elimination|team|tournament> | category <name> | dictionary <strict|broad> | warning <on|off>`)
                    writeJson(DATA_FILE, db)
                    return reply(`✅ WCG group setting updated: ${setting}.`)
                }
                if (sub === 'category') {
                    if (!isPrivileged) return reply('Only privileged users can manage WCG categories.')
                    const action = String(args[1] || '').toLowerCase()
                    const name = String(args[2] || '').toLowerCase().replace(/[^a-z0-9_-]/g, '')
                    if (action === 'list') return reply(Object.keys(db.system.wcgCategories).length ? `📚 Categories\n${Object.keys(db.system.wcgCategories).map(k => `𒆜 ${k} (${db.system.wcgCategories[k].length})`).join('\n')}` : '📚 No custom categories.')
                    if (action === 'add' && name) {
                        const words = args.slice(3).flatMap(v => String(v).split(',')).map(v => v.toLowerCase().replace(/[^a-z]/g,'')).filter(v => v.length >= 2)
                        if (!words.length) return reply(`Usage: ${getPrefix()}wcg category add <name> <word1,word2,...>`)
                        db.system.wcgCategories[name] = [...new Set(words)]; writeJson(DATA_FILE, db)
                        return reply(`📚 Category *${name}* saved with ${db.system.wcgCategories[name].length} words.`)
                    }
                    if (action === 'del' && name) { delete db.system.wcgCategories[name]; writeJson(DATA_FILE, db); return reply(`🗑️ Category *${name}* removed.`) }
                    return reply(`Usage: ${getPrefix()}wcg category list | add <name> <words> | del <name>`)
                }
                if (sub === 'settime' || (sub === 'set' && String(args[1] || '').toLowerCase() === 'time')) {
                    if (!isPrivileged) return reply('Only privileged users can configure WCG time.')
                    const a = args.slice(1).map(String)
                    const n = Number(a.find(v => /^\d+$/.test(v)) || 0)
                    if (!WCG_ALLOWED_TIMES.has(n)) return reply('Allowed WCG times: 20, 25, 30, 35, 40, 45, 50 seconds.')
                    const difficulty = a.find(v => ['easy','hard'].includes(v.toLowerCase())) || 'hard'
                    const d = difficulty.toLowerCase()
                    wcgConfig[d] = n
                    db.system.wcgTimes = wcgConfig
                    writeJson(DATA_FILE, db)
                    return reply(`*WCG Time Updated* ⚡\n𒆜 Difficulty ⫸ ${d.toUpperCase()}\n𒆜 Time ⫸ ${n}s`)
                }
                if (!['easy','hard','start','bot','blitz','elimination','team','tournament',''].includes(sub)) return reply(`${getPrefix()}wcg easy|hard|bot|blitz|elimination|team|tournament`)
                if (wcgGames.has(key)) return reply('A WCG game is already running here. 🔒\nNobody can join once the game is in play.')

                const metadata = x.isGroup ? await snowi.groupMetadata(from).catch(() => null) : null
                const firstPlayer = normalizeJid(sender, snowi)
                const bot = wcgBotJid(snowi)
                const challenge = isBotChallenge && !isBot && !!bot
                const players = challenge ? [firstPlayer, bot] : [firstPlayer]
                const participantList = [...(metadata?.participants || [])]
                for (const jid of players) {
                    if (!participantList.some(p => { try { return areJidsSameUser(normalizeJid(p.id, snowi), jid) } catch { return p.id === jid } })) {
                        participantList.push({ id: jid, notify: areJidsSameUser(jid, bot) ? (snowi.user?.name || snowi.user?.verifiedName || 'Yonder MD') : pushname })
                    }
                }
                const sessionId = crypto.randomUUID()
                const game = {
                    sessionId,
                    phase: 'lobby',
                    lobbyDeadline: Date.now() + 60000,
                    difficulty: isBotChallenge || ['blitz','elimination','team','tournament'].includes(sub) ? 'hard' : (['easy','hard'].includes(sub) ? sub : (x.isGroup ? getGroupSettings(from).wcg.difficulty : 'hard')),
                    time: isBotChallenge ? 25 : (x.isGroup ? Number(getGroupSettings(from).wcg.time) : Number(wcgConfig[(['easy','hard'].includes(sub) ? sub : 'hard')])),
                    players,
                    participants: participantList,
                    botMode: challenge ? 'auto' : (isBot && players.some(j => areJidsSameUser(j, bot)) ? 'self' : 'none'),
                    groupConfig: x.isGroup ? { ...getGroupSettings(from).wcg } : { difficulty: 'hard', time: Number(wcgConfig.hard), botDelay: Number(db.system.wcgBotDelay) || 7, mode: 'classic', category: 'general', strict: false },
                    turn: 0,
                    round: 1,
                    minLength: 4,
                    hardSubmissions: 0,
                    letter: String.fromCharCode(97 + crypto.randomInt(26)),
                    used: new Set(),
                    longest: null,
                    complex: null,
                    eliminated: [],
                    timer: null,
                    lobbyTimer: null,
                    lobbyNoticeTimer: null,
                    botMessageIds: new Set(),
                    allPlayers: [...players],
                    responseStartedAt: Date.now(),
                    invalidAttempts: {},
                    mode: ['blitz','elimination','team','tournament'].includes(sub) ? sub : ((x.isGroup ? getGroupSettings(from).wcg.mode : 'classic') || 'classic'),
                    category: (x.isGroup ? getGroupSettings(from).wcg.category : 'general') || 'general',
                    strict: !!(x.isGroup ? getGroupSettings(from).wcg.strict : false),
                    host: firstPlayer,
                }
                if (game.mode === 'blitz') game.time = Math.min(game.time, 10)
                if (game.mode === 'team') game.teams = game.players.reduce((acc, jid, i) => { (acc[i % 2] ||= []).push(jid); return acc }, [[], []])
                if (game.mode === 'tournament') game.tournament = { round: 1, format: 'single-elimination' }
                wcgGames.set(key, game)
                const firstName = displayNameForParticipant(participantList.find(p => { try { return areJidsSameUser(normalizeJid(p.id, snowi), firstPlayer) } catch { return p.id === firstPlayer } }), pushname)
                const opening = challenge
                    ? `🎯 *WCG BOT CHALLENGE* 🤖\n𒆜 Host ⫸ @${firstName}\n𒆜 Opponent ⫸ Yonder MD 🤖\n𒆜 Players ⫸ 2\n𒆜 Difficulty ⫸ HARD 💥\n𒆜 Join window ⫸ 60 seconds ⏳\n\nYonder will automatically answer its turns after ${Number((game.groupConfig?.botDelay) || db.system.wcgBotDelay) || 7} seconds.`
                    : `*WORD CHAIN LOBBY* 🚪🔥\n𒆜 Game ⫸ OPEN\n𒆜 Host ⫸ @${firstName}\n𒆜 Players ⫸ 1\n𒆜 Difficulty ⫸ ${game.difficulty.toUpperCase()} 💥\n𒆜 Join ⫸ 60 seconds ⏳\n𒆜 Need ⫸ 1+ more player\n\n🎮 Type ${getPrefix()}join to enter the arena!`
                await snowi.sendMessage(from, { text: opening, mentions: [firstPlayer, ...(challenge ? [bot] : [])] }, { quoted:m })
                const token = sessionId
                game.lobbyTimer = setTimeout(async () => {
                    const active = wcgGames.get(key)
                    if (active !== game || active.sessionId !== token || active.phase !== 'lobby') return
                    if (active.players.length >= 2) {
                        await startWcgAfterLobby(snowi, from, active)
                        return
                    }
                    await wcgEndGame(snowi, from, active, 'not-enough')
                }, 60000)
                game.lobbyNoticeTimer = setTimeout(async () => {
                    const active = wcgGames.get(key)
                    if (active !== game || active.sessionId !== token || active.phase !== 'lobby') return
                    await snowi.sendMessage(from, {
                        text: `⏳ *WCG LOBBY UPDATE*\n𒆜 30 seconds remain to join the game!\n𒆜 Players ⫸ ${active.players.length}\n\nAnyone can still join before the 60-second lobby closes. ⚔️`
                    }, { quoted: null }).catch(() => {})
                }, 30000)
                break
            }

            case 'join': {
                const key = wcgKey(from)
                const game = wcgGames.get(key)
                if (!game || game.phase !== 'lobby') {
                    // Never let a random .join wake the bot up in an unrelated chat.
                    if (!isPrivileged && !isBot) return
                    return reply('No WCG lobby is open here. Start a new game with .wcg. 🎮')
                }
                const mode = String(args[0] || '').toLowerCase()
                if (mode === 'self' || mode === 'bot') {
                    if (!isBot) return reply(`Only the bot account can use ${getPrefix()}join ${mode}.`)
                    const bot = wcgBotJid(snowi)
                    if (!bot) return reply('Bot account identity is unavailable.')
                    if (game.players.some(j => areJidsSameUser(j, bot))) {
                        game.botMode = mode === 'bot' ? 'auto' : 'self'
                        const label = game.botMode === 'auto' ? 'automated' : 'manually controlled'
                        return reply(`🤖 Yonder is already in this lobby. Bot mode is now ${label}.`)
                    }
                    game.players.push(bot)
                    game.botMode = mode === 'bot' ? 'auto' : 'self'
                    if (!game.participants.some(p => { try { return areJidsSameUser(normalizeJid(p.id, snowi), bot) } catch { return false } })) {
                        game.participants.push({ id: bot, notify: snowi.user?.name || snowi.user?.verifiedName || 'Yonder MD' })
                    }
                    const label = game.botMode === 'auto' ? 'automated' : 'manually controlled'
                    await snowi.sendMessage(from, { text: `🤖 *Yonder joined WCG!*
𒆜 Mode ⫸ ${label.toUpperCase()}
𒆜 Players ⫸ ${game.players.length}
𒆜 Lobby ⫸ OPEN ⏳

${game.botMode === 'auto' ? `Yonder will answer its turns after ${Number((game.groupConfig?.botDelay) || db.system.wcgBotDelay) || 7} seconds.` : 'Type the WCG words yourself from the bot account when it is Yonder’s turn.'}`, mentions:[bot] }, { quoted:null })
                    return
                }
                if (mode) return reply(`Usage: ${getPrefix()}join | ${getPrefix()}join self | ${getPrefix()}join bot`)
                const player = normalizeJid(sender, snowi)
                if (game.players.some(j => areJidsSameUser(j, player))) return reply('You are already in this WCG. 😎')
                game.players.push(player)
                if (x.isGroup) game.participants = (await snowi.groupMetadata(from).catch(() => null))?.participants || game.participants
                const map = wcgDisplayMap(game, snowi)
                const name = displayNameForParticipant(map.get(player), pushname)
                await snowi.sendMessage(from, { text: `🎉 @${name} joined WCG!
𒆜 Players ⫸ ${game.players.length}
𒆜 Lobby ⫸ OPEN ⏳

The lobby remains open until the full 60-second window ends. Keep joining! ⚔️`, mentions:[player] }, { quoted:null })
                break
            }

            case 'achievements':
            case 'badges': {
                const s = ensureWcgStat(normalizeJid(sender, snowi))
                const labels = { 'first-win':'🏆 First WCG Win', '10-wins':'🥇 10 WCG Wins', '100-words':'📚 100 Words Played', 'longest-word':'📖 Long Word Master', 'fast-response':'⚡ Fastest Response', 'perfect-streak':'🔥 Perfect Streak' }
                const list = s.achievements.length ? s.achievements.map(a => `𒆜 ${labels[a] || a}`).join('\n') : '𒆜 No achievements yet. Keep playing!'
                return reply(`🏆 *WCG ACHIEVEMENTS*\n${list}`)
            }

            case 'stats':
            case 'wcgstats': {
                const target = normalizeJid(sender, snowi)
                return reply(wcgStatsText(target, command === 'stats' ? 'PLAYER STATS' : 'WCG STATS'))
            }

            case 'leaderboard':
            case 'wcgleaderboard': {
                const rows = wcgLeaderboard(10)
                if (!rows.length) return reply('🏆 *WCG LEADERBOARD*\n𒆜 No ranked games have been recorded yet.')
                const mentions = rows.map(r => r.jid)
                const map = wcgDisplayMap({ participants: x.isGroup ? participants : [] }, snowi)
                const lines = rows.map((r, i) => {
                    const name = x.isGroup ? displayNameForParticipant(map.get(normalizeJid(r.jid, snowi)), numberOf(r.jid)) : (store?.contacts?.[r.jid]?.name || store?.contacts?.[r.jid]?.notify || numberOf(r.jid))
                    return `${i + 1}. @${String(name).replace(/\n/g,' ')} — ${r.wins}W / ${r.losses}L — ${r.words} words`
                })
                return reply(`🏆 *${command === 'leaderboard' ? 'GLOBAL LEADERBOARD' : 'WCG LEADERBOARD'}*\n${lines.join('\n')}`, { mentions })
            }

            case 'permissions': {
                if (!isPrivileged) return reply('Only privileged users can view the permission dashboard.')
                return reply(`🛡️ *YONDER PERMISSIONS*\n𒆜 Creator ⫸ ${CREATOR_NUMBER}\n𒆜 Admin ⫸ ${db.admins.length}\n𒆜 Sudo ⫸ ${db.sudo.length}\n𒆜 User ⫸ Standard access\n\n*Hierarchy*\nCreator → Admin → Sudo → User`)
            }

            case 'wcgconfig':
            case 'games': {
                if (!isPrivileged) return reply('Only privileged users can configure games.')
                if (!x.isGroup) return reply('Per-group game configuration must be used inside a group.')
                const g = getGroupSettings(from)
                const sub = String(args[0] || 'show').toLowerCase()
                const val = String(args[1] || '').toLowerCase()
                if (command === 'games' && (!sub || sub === 'show')) return reply(`🎮 *GROUP GAMES*\n𒆜 Enabled ⫸ ${g.wcg.games ? 'YES' : 'NO'}\n𒆜 WCG ⫸ ${g.wcg.games ? 'ON' : 'OFF'}`)
                if (command === 'games') {
                    g.wcg.games = ['on','enable','enabled','yes','true'].includes(sub) ? true : ['off','disable','disabled','no','false'].includes(sub) ? false : g.wcg.games
                    writeJson(DATA_FILE, db); return reply(`🎮 Group games are now *${g.wcg.games ? 'ON' : 'OFF'}*.`)
                }
                if (sub === 'show') return reply(`⚙️ *WCG GROUP CONFIG*\n𒆜 Difficulty ⫸ ${g.wcg.difficulty}\n𒆜 Timer ⫸ ${g.wcg.time}s\n𒆜 Bot delay ⫸ ${g.wcg.botDelay}s\n𒆜 Mode ⫸ ${g.wcg.mode}\n𒆜 Category ⫸ ${g.wcg.category}\n𒆜 Dictionary ⫸ ${g.wcg.strict ? 'STRICT' : 'BROAD'}\n𒆜 Invalid warning ⫸ ${g.wcg.invalidWarning ? 'ON' : 'OFF'}\n𒆜 Games ⫸ ${g.wcg.games ? 'ON' : 'OFF'}`)
                if (sub === 'difficulty' && ['easy','hard'].includes(val)) g.wcg.difficulty = val
                else if (sub === 'time' && WCG_ALLOWED_TIMES.has(Number(val))) g.wcg.time = Number(val)
                else if (sub === 'botdelay' && Number(val) >= 1 && Number(val) <= 19) g.wcg.botDelay = Number(val)
                else if (sub === 'mode' && ['classic','blitz','elimination','team','tournament'].includes(val)) g.wcg.mode = val
                else if (sub === 'category') g.wcg.category = val || 'general'
                else if (sub === 'dictionary' && ['strict','broad'].includes(val)) g.wcg.strict = val === 'strict'
                else if (sub === 'warning' && ['on','off'].includes(val)) g.wcg.invalidWarning = val === 'on'
                else return reply(`Usage: ${getPrefix()}wcgconfig difficulty <easy|hard>\n${getPrefix()}wcgconfig time <20|25|30|35|40|45|50>\n${getPrefix()}wcgconfig botdelay <1-19>\n${getPrefix()}wcgconfig mode <classic|blitz|elimination|team|tournament>\n${getPrefix()}wcgconfig category <name>\n${getPrefix()}wcgconfig dictionary <strict|broad>\n${getPrefix()}wcgconfig warning <on|off>`)
                writeJson(DATA_FILE, db)
                return reply(`✅ WCG group setting updated: ${sub} = ${sub === 'dictionary' ? (g.wcg.strict ? 'strict' : 'broad') : sub === 'warning' ? (g.wcg.invalidWarning ? 'on' : 'off') : (g.wcg[sub] ?? val)}`)
            }

            case 'battleversia':
            case 'bv': {
                await reply('⚔️ *Battleversia* is currently under development. The arena is being forged — full gameplay is not available yet.')
                break
            }

            case 'antibadword':
            case 'antispam':
            case 'antitag': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                if (!(await requireBotAdmin(isBotAdmins, reply))) break
                const current = !!group[command]
                group[command] = parseToggle(args[0], current)
                writeJson(DATA_FILE, db)
                await reply(`✅ ${command} is now *${group[command] ? 'ON' : 'OFF'}*.`)
                break
            }

            case 'addbadword': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                const words = q.toLowerCase().split(/[ ,]+/).map(v => v.trim()).filter(Boolean)
                if (!words.length) return reply(`Usage: ${getPrefix()}addbadword <word1> <word2> ...`)
                group.badwords = [...new Set([...group.badwords, ...words])]
                writeJson(DATA_FILE, db)
                await reply(`✅ Added ${words.length} bad word(s).`)
                break
            }

            case 'delbadword': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                const words = q.toLowerCase().split(/[ ,]+/).map(v => v.trim()).filter(Boolean)
                group.badwords = group.badwords.filter(w => !words.includes(w))
                writeJson(DATA_FILE, db)
                await reply('✅ Bad-word list updated.')
                break
            }

            case 'badwordlist': {
                if (!(await requireGroup(from, x, reply))) break
                if (!group.badwords.length) return reply('📋 Bad-word list is empty.')
                await reply(`📋 *Bad words*\n\n${group.badwords.map((w, i) => `${i + 1}. ${w}`).join('\n')}`)
                break
            }

            case 'add': {
                if (String(args[0] || '').toLowerCase() === 'admin') {
                    if (!isOwnerUser) return reply('Only the creator or bot account can add admins.')
                    const targetArgs = args.slice(1).join(' ')
                    const targets = getTargetJids(mentionxs, targetArgs, quotedMsg, snowi, quotedParticipant)
                    if (!targets.length) return reply(`Tag or reply to a user: ${getPrefix()}add admin @user`)
                    const target = targets[0]
                    if (areJidsSameUser(target, normalizedBot) || isOwner(target, snowi, false)) return reply('The creator and bot account already have full access and cannot be added as admins.')
                    if (!db.admins.some(j => areJidsSameUser(j, target))) db.admins.push(target)
                    writeJson(DATA_FILE, db)
                    const name = getDisplayNameFromGroup(participants, target, numberOf(target))
                    await reply(`*Yonder Admin* 👑\n𒆜 @${name} now has full non-owner bot command access.`, { mentions:[target] })
                    break
                }
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                if (!(await requireBotAdmin(isBotAdmins, reply))) break
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (!targets.length) return reply(`Tag or reply to the user you want to add: ${getPrefix()}add @user`)
                const safeTargets = targets.filter(j => !areJidsSameUser(j, botNumber))
                if (!safeTargets.length) return reply('I cannot add my own account.')
                await snowi.groupParticipantsUpdate(from, safeTargets, 'add')
                await reply(`*Yonder Group* ⚡\n𒆜 Add ⫸ Complete`, {mentions:safeTargets})
                break
            }

            case 'kick':
            case 'promote':
            case 'demote': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                if (!(await requireBotAdmin(isBotAdmins, reply))) break
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (!targets.length) return reply(`Tag or reply to the user you want to ${command}.`)
                const safeTargets = targets.filter(j => !areJidsSameUser(j, botNumber))
                if (!safeTargets.length) return reply('I cannot target my own account.')
                await snowi.groupParticipantsUpdate(from, safeTargets, command === 'kick' ? 'remove' : command)
                await reply(`✅ ${command} completed for ${safeTargets.length} user(s).`)
                break
            }

            case 'mute':
            case 'unmute': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                if (!(await requireBotAdmin(isBotAdmins, reply))) break
                group.mute = command === 'mute'
                writeJson(DATA_FILE, db)
                try { await snowi.groupSettingUpdate(from, command === 'mute' ? 'announcement' : 'not_announcement') } catch {}
                await reply(command === 'mute' ? '🔇 Group muted. Only admins can send messages while I enforce mute.' : '🔊 Group unmuted.')
                break
            }

            case 'tagall':
            case 'hidetag': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                const targets = participants.map(p => normalizeJid(p.id, snowi)).filter(Boolean)
                const lines = participants.map((p, i) => `${i + 1}. @${displayNameForParticipant(p, numberOf(p.id) || String(i + 1))}`)
                const caption = command === 'tagall'
                    ? `📢 *${groupName}*\n\n${lines.join('\n')}`
                    : `📢 *${groupName}*`
                await snowi.sendMessage(from, { text: caption, mentions: targets }, { quoted: m })
                break
            }

            case 'warn': {
                if (!(await requireGroup(from, x, reply))) break
                if (!isPrivileged) return reply('Only a privileged user can issue warnings.')
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (!targets.length) return reply(`Tag or reply to a user: ${getPrefix()}warn @user [reason]`)
                const target = targets[0]
                group.warnings[target] = (group.warnings[target] || 0) + 1
                writeJson(DATA_FILE, db)
                const count = group.warnings[target]
                await reply(`⚠️ Warning issued to @${getDisplayNameFromGroup(participants, target, numberOf(target))} · ${count}/5${q && !mentionxs.length ? `\nReason: ${q}` : ''}`, { mentions: [target] })
                if (count > 5 && isBotAdmins && !areJidsSameUser(target, botNumber)) {
                    try {
                        await snowi.groupParticipantsUpdate(from, [target], 'remove')
                        delete group.warnings[target]
                        writeJson(DATA_FILE, db)
                        await reply(`🚪 @${getDisplayNameFromGroup(participants, target, numberOf(target))} exceeded 5 warnings and was removed.`, { mentions: [target] })
                    } catch {}
                }
                break
            }

            case 'resetwarn': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (targets.length) delete group.warnings[targets[0]]
                else group.warnings = {}
                writeJson(DATA_FILE, db)
                await reply('✅ Warnings reset.')
                break
            }

            case 'warnings': {
                if (!(await requireGroup(from, x, reply))) break
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (targets.length) {
                    const target = targets[0]
                    const count = Math.min(Number(group.warnings[target] || 0), 5)
                    const name = getDisplayNameFromGroup(participants, target, numberOf(target))
                    return reply(`*WARNING PROFILE*\n𒆜 User ⫸ @${name}\n𒆜 Warns ⫸ ${count}/5\n𒆜 Left ⫸ ${Math.max(0, 5-count)}`, { mentions:[target] })
                }
                const entries = Object.entries(group.warnings)
                if (!entries.length) return reply('*WARNING PROFILE* ⚡\n𒆜 No active warnings.')
                const mentions = entries.map(([jid]) => jid)
                const lines = entries.map(([jid, count], i) => `${i + 1}. @${getDisplayNameFromGroup(participants, jid, numberOf(jid))} — ${Math.min(Number(count)||0,5)}/5`)
                await reply(`*WARNING PROFILES* ⚡\n${lines.join('\n')}`, { mentions })
                break
            }

            case 'welcome':
            case 'goodbye': {
                if (!(await requireGroup(from, x, reply))) break
                if (!(await requireAdmin(isAdmins || isPrivileged, isPrivileged, reply))) break
                const target = group[command]
                const sub = String(args[0] || '').toLowerCase()
                if (!sub) return reply(`Usage: ${getPrefix()}${command} on|off [message]\nPlaceholders: @user and {group}`)
                if (['on', 'off', 'enable', 'disable'].includes(sub)) {
                    target.enabled = ['on', 'enable'].includes(sub)
                    const msg = args.slice(1).join(' ').trim()
                    if (msg) target.text = msg
                } else {
                    target.enabled = true
                    target.text = q
                }
                writeJson(DATA_FILE, db)
                await reply(`✅ ${command} is now *${target.enabled ? 'ON' : 'OFF'}*.${target.enabled ? `\nMessage: ${target.text}` : ''}`)
                break
            }

            case 'plugin': {
                if (!isPrivileged) return reply('Only privileged users can manage plugins.')
                const action = String(args[0] || 'list').toLowerCase()
                if (action === 'list') {
                    const files = fs.readdirSync(PLUGIN_DIR).filter(f => f.endsWith('.js'))
                    return reply(files.length ? `🔌 *Plugins*\n${files.map((f, i) => `${i + 1}. ${f}`).join('\n')}` : '🔌 No plugins installed.')
                }
                if (action === 'del' || action === 'remove') {
                    const name = String(args[1] || '').replace(/[^a-zA-Z0-9._-]/g, '')
                    if (!name) return reply(`Usage: ${getPrefix()}plugin del <filename>`)
                    const file = name.endsWith('.js') ? name : `${name}.js`
                    const full = path.join(PLUGIN_DIR, file)
                    if (!fs.existsSync(full)) return reply('Plugin not found.')
                    fs.rmSync(full, { force: true })
                    for (const [cmd, p] of loadedPlugins) if (p.file === file) loadedPlugins.delete(cmd)
                    return reply(`✅ Removed ${file}.`)
                }
                if (action === 'add' || action === 'install') {
                    const url = args[1]
                    if (!url || !/^https?:\/\//i.test(url)) return reply(`Usage: ${getPrefix()}plugin add <https://.../plugin.js>`)
                    const response = await fetch(url)
                    if (!response.ok) throw new Error(`HTTP ${response.status}`)
                    const source = await response.text()
                    if (source.length > 300000) throw new Error('Plugin is too large (300 KB maximum).')
                    const name = (args[2] || path.basename(new URL(url).pathname) || `plugin-${Date.now()}`).replace(/[^a-zA-Z0-9._-]/g, '')
                    const file = name.endsWith('.js') ? name : `${name}.js`
                    fs.writeFileSync(path.join(PLUGIN_DIR, file), source, 'utf8')
                    await loadPlugins()
                    return reply(`✅ Plugin installed: ${file}`)
                }
                return reply(`🔌 Plugin commands:\n${getPrefix()}plugin list\n${getPrefix()}plugin add <url> [name]\n${getPrefix()}plugin del <name>`)
            }

            case 'deladmin': {
                if (!isOwnerUser) return reply('Only the creator or bot account can remove admins.')
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (!targets.length) return reply(`Tag or reply to a user: ${getPrefix()}deladmin @user`)
                const target = targets[0]
                db.admins = db.admins.filter(j => !areJidsSameUser(j, target))
                writeJson(DATA_FILE, db)
                const name = getDisplayNameFromGroup(participants, target, numberOf(target))
                await reply(`*Yonder Admin* 👑\n𒆜 @${name} has been removed from admin access.`, { mentions:[target] })
                break
            }

            case 'admin': {
                const sub = String(args[0] || '').toLowerCase()
                if (sub !== 'list') return reply(`Usage: ${getPrefix()}admin list`)
                if (!isPrivileged) return reply('Only a privileged user can view the admin list.')
                if (!db.admins.length) return reply('*Yonder Admin* 👑\n𒆜 No admins are configured yet.')
                const adminLines = db.admins.map((j, i) => {
                    const name = x.isGroup ? getDisplayNameFromGroup(participants, j, numberOf(j)) : (store?.contacts?.[j]?.name || store?.contacts?.[j]?.notify || numberOf(j))
                    return `${i + 1}. @${String(name).replace(/\n/g, ' ')}`
                })
                await reply(`*Yonder Admin* 👑\n${adminLines.join('\n')}`, { mentions: db.admins })
                break
            }

            case 'setsudo':
            case 'delsudo': {
                if (!isPrivileged) return reply('Only privileged users can manage sudo users.')
                const targets = getTargetJids(mentionxs, q, quotedMsg, snowi, quotedParticipant)
                if (!targets.length) return reply(`Tag or reply to a user: ${getPrefix()}${command} @user`)
                const target = targets[0]
                if (command === 'setsudo') {
                    if (!db.sudo.includes(target)) db.sudo.push(target)
                    writeJson(DATA_FILE, db)
                    const sudoName = getDisplayNameFromGroup(participants, target, numberOf(target)); await reply(`*Sudo Updated* 👑\n𒆜 @${sudoName} is now sudo.`, { mentions: [target] })
                } else {
                    db.sudo = db.sudo.filter(j => !areJidsSameUser(j, target))
                    writeJson(DATA_FILE, db)
                    const sudoName = getDisplayNameFromGroup(participants, target, numberOf(target)); await reply(`*Sudo Updated* 👑\n𒆜 @${sudoName} has been removed from sudo.`, { mentions: [target] })
                }
                break
            }

            case 'sudolist':
            case 'sudo': {
                if (command === 'sudo' && String(args[0] || '').toLowerCase() !== 'list') return reply(`Usage: ${getPrefix()}sudo list`)
                if (!isPrivileged) return reply('Only privileged users can view the sudo list.')
                if (!db.sudo.length) return reply('*Yonder Sudo* 👑\n𒆜 No sudo users are configured yet.\nThe inner circle is empty. ⚡')
                const sudoLines = db.sudo.map((j, i) => {
                    const name = x.isGroup ? getDisplayNameFromGroup(participants, j, numberOf(j)) : (store?.contacts?.[j]?.name || store?.contacts?.[j]?.notify || numberOf(j))
                    return `${i + 1}. @${String(name).replace(/\n/g,' ')}`
                })
                await reply(`*Yonder Sudo* 👑\n${sudoLines.join('\n')}`, { mentions: db.sudo })
                break
            }

            // Existing utility commands retained from the original base.
            case 'aonc':
            case 'oncv': {
                if (!quotedMsg) return reply('Reply to a view-once image, video or audio.')
                const copy = JSON.parse(JSON.stringify(quotedMsg))
                for (const key of ['videoMessage', 'imageMessage', 'audioMessage']) if (copy[key]?.viewOnce) copy[key].viewOnce = false
                await snowi.relayMessage(from, copy, {})
                break
            }

            case 'me': {
                if (!isOwnerUser) return reply('Creator / bot account only.')
                await reply(meJid)
                break
            }

            case 'from': {
                if (!isOwnerUser) return reply('Creator / bot account only.')
                await reply(from)
                break
            }

            case 'restart': {
                if (!isPrivileged) return reply('Privileged users only.')
                await reply('Restarting...')
                process.exit(1)
                break
            }

            case 'info': {
                if (!isPrivileged) return reply('Privileged users only.')
                await reply(JSON.stringify(quotedMsg || {}, null, 2))
                break
            }

            case 'test': {
                await reply('Yonder MD is online.')
                break
            }

            default:
                break
        }
    } catch (e) {
        console.log(util.format(e))
    }
}


async function handleGroupParticipantsUpdate(snowi, update) {
    try {
        const jid = update?.id
        if (!jid || !jid.endsWith('@g.us')) return
        const group = getGroupSettings(jid)
        const metadata = await snowi.groupMetadata(jid).catch(() => null)
        const subject = metadata?.subject || 'the group'
        const action = update?.action
        const users = Array.isArray(update?.participants) ? update.participants : []
        if (!users.length) return
        const textTemplate = action === 'add' ? group.welcome : action === 'remove' ? group.goodbye : null
        if (!textTemplate?.enabled) return
        for (const rawJid of users) {
            const userJid = normalizeJid(rawJid, snowi)
            const participant = metadata?.participants?.find(p => normalizeJid(p.id, snowi) === userJid)
            const display = participant?.notify || participant?.name || numberOf(userJid)
            const text = String(textTemplate.text || '')
                .replace(/@user/g, `@${display}`)
                .replace(/\{group\}/g, subject)
            await snowi.sendMessage(jid, { text, mentions: [userJid] })
        }
    } catch (e) {
        console.log('Yonder group participant error:', e.message || e)
    }
}

module.exports.handleGroupParticipantsUpdate = handleGroupParticipantsUpdate

let file = require.resolve(__filename)
fs.watchFile(file, { interval: 500 }, () => {
    fs.unwatchFile(file)
    delete require.cache[file]
    console.log(`Update ${__filename}`)
})
