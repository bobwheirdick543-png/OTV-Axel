-- ============================================================================
-- Yonder MD — Supabase persistence schema
-- Safe to run repeatedly: every statement is idempotent (IF NOT EXISTS / OR
-- REPLACE) and nothing here ever drops or truncates existing data.
-- ============================================================================

create table if not exists public.schema_migrations (
  version text primary key,
  description text not null default '',
  applied_at timestamptz not null default now()
);

-- Generic "bump synced timestamp" trigger used by every table below.
create or replace function public.touch_synced_at()
returns trigger language plpgsql as $$
begin
  new._synced_at = now();
  return new;
end;
$$;

-- ----------------------------------------------------------------------------
-- Core bot state (groups, sudo, admins, prefix, WCG stats, etc.)
-- Already targeted by lib/supabase-persistence.js (id='bot_state'). Declared
-- here so the whole schema is reproducible from this one file.
-- ----------------------------------------------------------------------------
create table if not exists public.yonder_persistent_state (
  id text primary key,
  payload_json jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.yonder_persistent_state enable row level security;

-- ----------------------------------------------------------------------------
-- Battleversia — real per-entity tables (mirrors dev/data/battleversia.sqlite
-- exactly, column for column, so nothing in lib/battleversia.js's game logic
-- has to change).
-- ----------------------------------------------------------------------------

create table if not exists public.bv_economy_transactions (
  transaction_id text primary key,
  idempotency_key text unique,
  timestamp bigint not null,
  sender_jid text,
  recipient_jid text,
  amount bigint not null,
  currency text not null default 'YN',
  transaction_type text not null,
  source text not null,
  status text not null,
  metadata_json jsonb not null default '{}'::jsonb,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_economy_sender on public.bv_economy_transactions(sender_jid, timestamp desc);
create index if not exists idx_bv_economy_recipient on public.bv_economy_transactions(recipient_jid, timestamp desc);

create table if not exists public.bv_profiles (
  jid text primary key,
  display_name text,
  balance bigint not null default 0,
  rating bigint not null default 0,
  games_played bigint not null default 0,
  wins bigint not null default 0,
  losses bigint not null default 0,
  draws bigint not null default 0,
  streak bigint not null default 0,
  best_streak bigint not null default 0,
  xp bigint not null default 0,
  level bigint not null default 1,
  net_worth bigint not null default 0,
  title text not null default 'Rookie',
  season_wins bigint not null default 0,
  season_points bigint not null default 0,
  achievements_json jsonb not null default '[]'::jsonb,
  passport_json jsonb not null default '{}'::jsonb,
  mastery_json jsonb not null default '{}'::jsonb,
  hall_of_legends bigint not null default 0,
  created_at bigint,
  updated_at bigint,
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_characters (
  id text primary key,
  verse text,
  name text,
  form text,
  overall_rank bigint,
  verse_rank bigint,
  score bigint,
  rarity text,
  source_text text,
  starting_bid bigint not null default 1000,
  market_price bigint not null default 0,
  available_from bigint,
  available_until bigint,
  active bigint not null default 1,
  ability_tags_json jsonb not null default '[]'::jsonb,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_characters_verse on public.bv_characters(verse, active);
create index if not exists idx_bv_characters_rank on public.bv_characters(overall_rank);

create table if not exists public.bv_character_ownership (
  jid text not null,
  character_id text not null,
  price_paid bigint,
  acquired_at bigint,
  primary key (jid, character_id),
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_games (
  game_id text primary key,
  group_jid text,
  started_by text,
  phase text,
  mode text,
  max_players bigint,
  slots_per_player bigint,
  entry_fee bigint,
  round_wallet bigint,
  character_count bigint,
  bonus_pool bigint,
  bid_increment bigint,
  bid_time_ms bigint,
  characters_json jsonb,
  auction_index bigint not null default 0,
  current_character_id text,
  current_bid bigint not null default 0,
  highest_bidder text,
  passed_by_json jsonb not null default '[]'::jsonb,
  used_character_ids_json jsonb not null default '[]'::jsonb,
  auction_deadline bigint,
  state_json jsonb,
  created_at bigint,
  updated_at bigint,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_games_group on public.bv_games(group_jid);

create table if not exists public.bv_game_players (
  game_id text not null,
  jid text not null,
  display_name text,
  entry_paid bigint,
  wallet bigint,
  spent bigint,
  score bigint,
  characters_json jsonb not null default '[]'::jsonb,
  primary key (game_id, jid),
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_game_events (
  id bigint primary key,
  game_id text,
  actor_jid text,
  action text,
  data_json jsonb,
  created_at bigint,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_game_events_game on public.bv_game_events(game_id, created_at);

create table if not exists public.bv_game_servers (
  server_id text primary key,
  name text unique,
  description text,
  owner_jid text,
  group_jid text,
  status text,
  entry_fee bigint,
  wallet_mode text,
  starting_wallet bigint,
  max_players bigint,
  betting_enabled bigint,
  start_at bigint,
  end_at bigint,
  config_json jsonb not null default '{}'::jsonb,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_game_servers_group on public.bv_game_servers(group_jid);

create table if not exists public.bv_gs_players (
  server_id text not null,
  jid text not null,
  entry_paid bigint,
  wallet bigint,
  joined_at bigint,
  primary key (server_id, jid),
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_gs_bets (
  id bigint primary key,
  server_id text,
  bettor_jid text,
  target_jid text,
  amount bigint,
  status text not null default 'OPEN',
  payout bigint not null default 0,
  created_at bigint,
  settled_at bigint,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_gs_bets_server on public.bv_gs_bets(server_id, status);

create table if not exists public.bv_tournaments (
  tournament_id text primary key,
  name text unique,
  description text,
  owner_jid text,
  prize_pool bigint,
  entry_fee bigint,
  min_players bigint,
  max_players bigint,
  format text,
  wallet_mode text,
  starting_wallet bigint,
  registration_open_at bigint,
  registration_close_at bigint,
  start_at bigint,
  end_at bigint,
  status text,
  paid_out bigint not null default 0,
  config_json jsonb not null default '{}'::jsonb,
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_tournament_players (
  tournament_id text not null,
  jid text not null,
  entry_paid bigint,
  joined_at bigint,
  primary key (tournament_id, jid),
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_tournament_servers (
  tournament_id text not null,
  server_id text not null,
  round_no bigint,
  match_no bigint,
  primary key (tournament_id, server_id),
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_airdrops (
  id text primary key,
  type text,
  value_json jsonb,
  drop_at bigint,
  created_by text,
  claims_json jsonb not null default '[]'::jsonb,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_airdrops_drop_at on public.bv_airdrops(drop_at);

create table if not exists public.bv_seasons (
  season_id text primary key,
  name text unique,
  start_at bigint,
  end_at bigint,
  prize_pool bigint,
  status text,
  announcement text,
  announcement_at bigint,
  owner_jid text,
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_settings (
  key text primary key,
  value_json jsonb,
  _synced_at timestamptz not null default now()
);

create table if not exists public.bv_audit (
  id bigint primary key,
  actor_jid text,
  action text,
  target text,
  details_json jsonb,
  created_at bigint,
  _synced_at timestamptz not null default now()
);
create index if not exists idx_bv_audit_created_at on public.bv_audit(created_at desc);
create index if not exists idx_bv_audit_actor on public.bv_audit(actor_jid, created_at desc);

create table if not exists public.bv_memory (
  key text primary key,
  value_json jsonb,
  updated_at bigint,
  _synced_at timestamptz not null default now()
);

-- Auto-bump _synced_at on every push (idempotent trigger creation).
do $$
declare t text;
begin
  for t in select unnest(array[
    'bv_economy_transactions','bv_profiles','bv_characters','bv_character_ownership','bv_games','bv_game_players',
    'bv_game_events','bv_game_servers','bv_gs_players','bv_gs_bets','bv_tournaments',
    'bv_tournament_players','bv_tournament_servers','bv_airdrops','bv_seasons',
    'bv_settings','bv_audit','bv_memory'
  ])
  loop
    execute format('drop trigger if exists trg_touch_synced_at on public.%I', t);
    execute format('create trigger trg_touch_synced_at before update on public.%I for each row execute function public.touch_synced_at()', t);
  end loop;
end $$;

-- Lock every Battleversia table down from the public/anon key. The bot talks
-- to Supabase with the service_role key (server-side only, never shipped to
-- users), which bypasses RLS by design. No policies are added on purpose —
-- that keeps these tables completely unreachable via the anon/publishable key.
do $$
declare t text;
begin
  for t in select unnest(array[
    'bv_economy_transactions','bv_profiles','bv_characters','bv_character_ownership','bv_games','bv_game_players',
    'bv_game_events','bv_game_servers','bv_gs_players','bv_gs_bets','bv_tournaments',
    'bv_tournament_players','bv_tournament_servers','bv_airdrops','bv_seasons',
    'bv_settings','bv_audit','bv_memory'
  ])
  loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

insert into public.schema_migrations (version, description)
values ('001_battleversia_core', 'Core Battleversia + bot-state persistence tables'),
('002_battleversia_economy_transactions', 'Persistent atomic Yons economy transaction ledger')
on conflict (version) do nothing;

-- 003_battleversia_expanded_features: durable character progression, games, tournaments, achievements and ledger.
create table if not exists public.bv_character_mastery (jid text, character_id text, uses bigint default 0, wins bigint default 0, losses bigint default 0, draws bigint default 0, xp bigint default 0, mastery_level bigint default 1, mastery_points bigint default 0, best_result text default '', last_used bigint, primary key(jid,character_id));
create table if not exists public.bv_character_trades (trade_id text primary key, from_jid text, to_jid text, character_id text, status text default 'PENDING', created_at bigint, accepted_at bigint, cancelled_at bigint, metadata_json jsonb default '{}'::jsonb);
create table if not exists public.bv_character_upgrades (jid text, character_id text, level bigint default 0, xp bigint default 0, modifiers_json jsonb default '{}'::jsonb, updated_at bigint, primary key(jid,character_id));
create table if not exists public.bv_character_research (research_id text primary key, character_id text, query text, result_json jsonb, source text, created_at bigint);
create table if not exists public.bv_character_match_history (id bigint primary key, character_a_id text, character_b_id text, winner text, game_id text, created_at bigint, details_json jsonb default '{}'::jsonb);
create table if not exists public.bv_gs_transactions (transaction_id text primary key, server_id text, jid text, type text, amount bigint default 0, status text, created_at bigint, metadata_json jsonb default '{}'::jsonb);
create table if not exists public.bv_tournament_rounds (tournament_id text, round_no bigint, status text, created_at bigint, completed_at bigint, primary key(tournament_id,round_no));
create table if not exists public.bv_tournament_matches (match_id text primary key, tournament_id text, round_no bigint, match_no bigint, server_id text, player_a text, player_b text, winner_jid text, status text default 'PENDING', created_at bigint, completed_at bigint, metadata_json jsonb default '{}'::jsonb);
create table if not exists public.bv_achievements (achievement_id text primary key, name text unique, description text, metric text, threshold bigint default 1, scope text default 'battleversia', active bigint default 1);
create table if not exists public.bv_achievement_progress (jid text, achievement_id text, progress bigint default 0, unlocked_at bigint, primary key(jid,achievement_id));
create table if not exists public.bv_economy_ledger (ledger_id text primary key, transaction_id text, jid text, direction text, amount bigint, balance_after bigint, created_at bigint, metadata_json jsonb default '{}'::jsonb);
create table if not exists public.bv_airdrop_claims (airdrop_id text, jid text, claimed_at bigint, transaction_id text, primary key(airdrop_id,jid));
insert into public.schema_migrations(version,description) values ('003_battleversia_expanded_features','Expanded persistent character, economy, Game Server, tournament, season, airdrop and achievement support') on conflict(version) do nothing;

alter table public.bv_characters add column if not exists strengths_json jsonb default '[]'::jsonb;
alter table public.bv_characters add column if not exists weaknesses_json jsonb default '[]'::jsonb;
alter table public.bv_characters add column if not exists win_conditions_json jsonb default '[]'::jsonb;
alter table public.bv_characters add column if not exists lose_conditions_json jsonb default '[]'::jsonb;
alter table public.bv_characters add column if not exists high_level_tags_json jsonb default '[]'::jsonb;
alter table public.bv_characters add column if not exists tradeable bigint default 1;
alter table public.bv_characters add column if not exists research_version bigint default 1;
alter table public.bv_characters add column if not exists updated_at bigint;

alter table public.bv_airdrops add column if not exists status text default 'SCHEDULED';

-- V2.3 Battleversia competitive enhancements (additive migration)
alter table public.bv_games add column if not exists competition_mode text default 'ranked';
alter table public.bv_games add column if not exists rating_enabled bigint default 1;
alter table public.bv_characters add column if not exists strengths_json jsonb not null default '[]'::jsonb;
alter table public.bv_characters add column if not exists weaknesses_json jsonb not null default '[]'::jsonb;
alter table public.bv_characters add column if not exists win_conditions_json jsonb not null default '[]'::jsonb;
alter table public.bv_characters add column if not exists lose_conditions_json jsonb not null default '[]'::jsonb;
alter table public.bv_characters add column if not exists high_level_tags_json jsonb not null default '[]'::jsonb;
alter table public.bv_characters add column if not exists tradeable bigint default 1;
alter table public.bv_characters add column if not exists research_version bigint default 1;
alter table public.bv_characters add column if not exists updated_at bigint;

create table if not exists public.bv_battle_replays (
  replay_id text primary key, game_id text unique, competition_mode text default 'ranked',
  winner_jid text, result text, created_at bigint, replay_json jsonb not null default '{}'::jsonb,
  _synced_at timestamptz not null default now()
);
create table if not exists public.bv_drafts (
  draft_id text primary key, group_jid text, started_by text, phase text default 'LOBBY', mode text,
  max_players bigint default 5, slots_per_player bigint default 3, entry_fee bigint default 0,
  pick_deadline bigint, turn_index bigint default 0, round_no bigint default 1, state_json jsonb not null default '{}'::jsonb,
  created_at bigint, updated_at bigint, _synced_at timestamptz not null default now()
);
create table if not exists public.bv_draft_players (
  draft_id text not null, jid text not null, display_name text, entry_paid bigint default 0,
  characters_json jsonb not null default '[]'::jsonb, joined_at bigint, primary key(draft_id,jid), _synced_at timestamptz not null default now()
);
create table if not exists public.bv_season_rewards (
  season_id text not null, jid text not null, placement bigint, reward_amount bigint default 0,
  claimed_at bigint, primary key(season_id,jid), _synced_at timestamptz not null default now()
);


-- Battleversia auction visibility + intelligent Game Server command proposals
alter table if exists public.bv_games add column if not exists auction_visibility_json jsonb default '{"show_rank":false,"show_score":false}'::jsonb;
create table if not exists public.bv_gs_command_proposals (proposal_id text primary key, server_id text, command_name text, aliases_json jsonb default '[]'::jsonb, description text, handler_hint text, status text default 'PENDING', analysis_json jsonb default '{}'::jsonb, created_at bigint, decided_at bigint);


alter table if exists public.bv_characters add column if not exists market_enabled integer default 1;
create table if not exists public.bv_gs_command_events (event_id text primary key, server_id text, jid text, command_name text, args_json jsonb default '[]'::jsonb, result_json jsonb default '{}'::jsonb, created_at bigint);
